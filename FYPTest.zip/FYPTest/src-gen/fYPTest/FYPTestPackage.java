/**
 */
package fYPTest;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see fYPTest.FYPTestFactory
 * @model kind="package"
 * @generated
 */
public interface FYPTestPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "fYPTest";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/fYPTest";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "fYPTest";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FYPTestPackage eINSTANCE = fYPTest.impl.FYPTestPackageImpl.init();

	/**
	 * The meta object id for the '{@link fYPTest.impl.BuildingImpl <em>Building</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.BuildingImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getBuilding()
	 * @generated
	 */
	int BUILDING = 0;

	/**
	 * The feature id for the '<em><b>Building ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING__BUILDING_ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING__NAME = 1;

	/**
	 * The feature id for the '<em><b>Model3 DPath</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING__MODEL3_DPATH = 2;

	/**
	 * The feature id for the '<em><b>Floor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING__FLOOR = 3;

	/**
	 * The feature id for the '<em><b>Digital Twins</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING__DIGITAL_TWINS = 4;

	/**
	 * The feature id for the '<em><b>Owns</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING__OWNS = 5;

	/**
	 * The number of structural features of the '<em>Building</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Building</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.FloorImpl <em>Floor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.FloorImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getFloor()
	 * @generated
	 */
	int FLOOR = 1;

	/**
	 * The feature id for the '<em><b>Floor ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOOR__FLOOR_ID = 0;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOOR__AREA = 1;

	/**
	 * The feature id for the '<em><b>Room</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOOR__ROOM = 2;

	/**
	 * The feature id for the '<em><b>Building</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOOR__BUILDING = 3;

	/**
	 * The number of structural features of the '<em>Floor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOOR_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Floor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.RoomImpl <em>Room</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.RoomImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getRoom()
	 * @generated
	 */
	int ROOM = 2;

	/**
	 * The feature id for the '<em><b>Room ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__ROOM_ID = 0;

	/**
	 * The feature id for the '<em><b>Room Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__ROOM_NAME = 1;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__AREA = 2;

	/**
	 * The feature id for the '<em><b>Current Temp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__CURRENT_TEMP = 3;

	/**
	 * The feature id for the '<em><b>Energy Usage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__ENERGY_USAGE = 4;

	/**
	 * The feature id for the '<em><b>Sensors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__SENSORS = 5;

	/**
	 * The feature id for the '<em><b>Hvac</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__HVAC = 6;

	/**
	 * The number of structural features of the '<em>Room</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Room</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.SensorImpl <em>Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.SensorImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getSensor()
	 * @generated
	 */
	int SENSOR = 3;

	/**
	 * The feature id for the '<em><b>Sensor ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__SENSOR_ID = 0;

	/**
	 * The feature id for the '<em><b>Sensor Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__SENSOR_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Time Stamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__TIME_STAMP = 2;

	/**
	 * The feature id for the '<em><b>Room ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__ROOM_ID = 3;

	/**
	 * The feature id for the '<em><b>Room</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__ROOM = 4;

	/**
	 * The number of structural features of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.EnergyMeterImpl <em>Energy Meter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.EnergyMeterImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getEnergyMeter()
	 * @generated
	 */
	int ENERGY_METER = 4;

	/**
	 * The feature id for the '<em><b>Sensor ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER__SENSOR_ID = SENSOR__SENSOR_ID;

	/**
	 * The feature id for the '<em><b>Sensor Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER__SENSOR_TYPE = SENSOR__SENSOR_TYPE;

	/**
	 * The feature id for the '<em><b>Time Stamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER__TIME_STAMP = SENSOR__TIME_STAMP;

	/**
	 * The feature id for the '<em><b>Room ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER__ROOM_ID = SENSOR__ROOM_ID;

	/**
	 * The feature id for the '<em><b>Room</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER__ROOM = SENSOR__ROOM;

	/**
	 * The feature id for the '<em><b>Energy Consumed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER__ENERGY_CONSUMED = SENSOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Energy Meter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER_FEATURE_COUNT = SENSOR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Energy Meter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENERGY_METER_OPERATION_COUNT = SENSOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.TemperatureSensorImpl <em>Temperature Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.TemperatureSensorImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getTemperatureSensor()
	 * @generated
	 */
	int TEMPERATURE_SENSOR = 5;

	/**
	 * The feature id for the '<em><b>Sensor ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR__SENSOR_ID = SENSOR__SENSOR_ID;

	/**
	 * The feature id for the '<em><b>Sensor Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR__SENSOR_TYPE = SENSOR__SENSOR_TYPE;

	/**
	 * The feature id for the '<em><b>Time Stamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR__TIME_STAMP = SENSOR__TIME_STAMP;

	/**
	 * The feature id for the '<em><b>Room ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR__ROOM_ID = SENSOR__ROOM_ID;

	/**
	 * The feature id for the '<em><b>Room</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR__ROOM = SENSOR__ROOM;

	/**
	 * The feature id for the '<em><b>Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR__TEMPERATURE = SENSOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Temperature Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR_FEATURE_COUNT = SENSOR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Temperature Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOR_OPERATION_COUNT = SENSOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.HVACSystemImpl <em>HVAC System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.HVACSystemImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getHVACSystem()
	 * @generated
	 */
	int HVAC_SYSTEM = 6;

	/**
	 * The feature id for the '<em><b>Hvac ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM__HVAC_ID = 0;

	/**
	 * The feature id for the '<em><b>Power Usage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM__POWER_USAGE = 1;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM__STATUS = 2;

	/**
	 * The feature id for the '<em><b>Linked Room</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM__LINKED_ROOM = 3;

	/**
	 * The feature id for the '<em><b>Room</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM__ROOM = 4;

	/**
	 * The number of structural features of the '<em>HVAC System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>HVAC System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HVAC_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.PredictiveModelImpl <em>Predictive Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.PredictiveModelImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getPredictiveModel()
	 * @generated
	 */
	int PREDICTIVE_MODEL = 7;

	/**
	 * The feature id for the '<em><b>Model ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL__MODEL_ID = 0;

	/**
	 * The feature id for the '<em><b>Model Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL__MODEL_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Input Var</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL__INPUT_VAR = 2;

	/**
	 * The feature id for the '<em><b>Output Var</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL__OUTPUT_VAR = 3;

	/**
	 * The feature id for the '<em><b>Accuracy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL__ACCURACY = 4;

	/**
	 * The feature id for the '<em><b>Last Trained</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL__LAST_TRAINED = 5;

	/**
	 * The number of structural features of the '<em>Predictive Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Predictive Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTIVE_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.DigitalTwinImpl <em>Digital Twin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.DigitalTwinImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getDigitalTwin()
	 * @generated
	 */
	int DIGITAL_TWIN = 8;

	/**
	 * The feature id for the '<em><b>Twin ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_TWIN__TWIN_ID = 0;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_TWIN__STATUS = 1;

	/**
	 * The feature id for the '<em><b>Last Update Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_TWIN__LAST_UPDATE_TIME = 2;

	/**
	 * The feature id for the '<em><b>Predictive Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_TWIN__PREDICTIVE_MODEL = 3;

	/**
	 * The number of structural features of the '<em>Digital Twin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_TWIN_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Digital Twin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_TWIN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.impl.DataManagerImpl <em>Data Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.impl.DataManagerImpl
	 * @see fYPTest.impl.FYPTestPackageImpl#getDataManager()
	 * @generated
	 */
	int DATA_MANAGER = 9;

	/**
	 * The feature id for the '<em><b>Data Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER__DATA_SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Update Interval</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER__UPDATE_INTERVAL = 1;

	/**
	 * The feature id for the '<em><b>Last Sync</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER__LAST_SYNC = 2;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER__STATUS = 3;

	/**
	 * The feature id for the '<em><b>Monitor Sensor</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER__MONITOR_SENSOR = 4;

	/**
	 * The feature id for the '<em><b>Pass Data</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER__PASS_DATA = 5;

	/**
	 * The number of structural features of the '<em>Data Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Data Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fYPTest.SensorType <em>Sensor Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fYPTest.SensorType
	 * @see fYPTest.impl.FYPTestPackageImpl#getSensorType()
	 * @generated
	 */
	int SENSOR_TYPE = 10;

	/**
	 * Returns the meta object for class '{@link fYPTest.Building <em>Building</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Building</em>'.
	 * @see fYPTest.Building
	 * @generated
	 */
	EClass getBuilding();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Building#getBuildingID <em>Building ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Building ID</em>'.
	 * @see fYPTest.Building#getBuildingID()
	 * @see #getBuilding()
	 * @generated
	 */
	EAttribute getBuilding_BuildingID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Building#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see fYPTest.Building#getName()
	 * @see #getBuilding()
	 * @generated
	 */
	EAttribute getBuilding_Name();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Building#getModel3DPath <em>Model3 DPath</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model3 DPath</em>'.
	 * @see fYPTest.Building#getModel3DPath()
	 * @see #getBuilding()
	 * @generated
	 */
	EAttribute getBuilding_Model3DPath();

	/**
	 * Returns the meta object for the containment reference list '{@link fYPTest.Building#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Floor</em>'.
	 * @see fYPTest.Building#getFloor()
	 * @see #getBuilding()
	 * @generated
	 */
	EReference getBuilding_Floor();

	/**
	 * Returns the meta object for the containment reference '{@link fYPTest.Building#getDigitalTwins <em>Digital Twins</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Digital Twins</em>'.
	 * @see fYPTest.Building#getDigitalTwins()
	 * @see #getBuilding()
	 * @generated
	 */
	EReference getBuilding_DigitalTwins();

	/**
	 * Returns the meta object for the containment reference '{@link fYPTest.Building#getOwns <em>Owns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Owns</em>'.
	 * @see fYPTest.Building#getOwns()
	 * @see #getBuilding()
	 * @generated
	 */
	EReference getBuilding_Owns();

	/**
	 * Returns the meta object for class '{@link fYPTest.Floor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Floor</em>'.
	 * @see fYPTest.Floor
	 * @generated
	 */
	EClass getFloor();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Floor#getFloorID <em>Floor ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Floor ID</em>'.
	 * @see fYPTest.Floor#getFloorID()
	 * @see #getFloor()
	 * @generated
	 */
	EAttribute getFloor_FloorID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Floor#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see fYPTest.Floor#getArea()
	 * @see #getFloor()
	 * @generated
	 */
	EAttribute getFloor_Area();

	/**
	 * Returns the meta object for the containment reference list '{@link fYPTest.Floor#getRoom <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Room</em>'.
	 * @see fYPTest.Floor#getRoom()
	 * @see #getFloor()
	 * @generated
	 */
	EReference getFloor_Room();

	/**
	 * Returns the meta object for the container reference '{@link fYPTest.Floor#getBuilding <em>Building</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Building</em>'.
	 * @see fYPTest.Floor#getBuilding()
	 * @see #getFloor()
	 * @generated
	 */
	EReference getFloor_Building();

	/**
	 * Returns the meta object for class '{@link fYPTest.Room <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Room</em>'.
	 * @see fYPTest.Room
	 * @generated
	 */
	EClass getRoom();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Room#getRoomID <em>Room ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Room ID</em>'.
	 * @see fYPTest.Room#getRoomID()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_RoomID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Room#getRoomName <em>Room Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Room Name</em>'.
	 * @see fYPTest.Room#getRoomName()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_RoomName();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Room#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see fYPTest.Room#getArea()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_Area();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Room#getCurrentTemp <em>Current Temp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Temp</em>'.
	 * @see fYPTest.Room#getCurrentTemp()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_CurrentTemp();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Room#getEnergyUsage <em>Energy Usage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Energy Usage</em>'.
	 * @see fYPTest.Room#getEnergyUsage()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_EnergyUsage();

	/**
	 * Returns the meta object for the containment reference list '{@link fYPTest.Room#getSensors <em>Sensors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sensors</em>'.
	 * @see fYPTest.Room#getSensors()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Sensors();

	/**
	 * Returns the meta object for the containment reference '{@link fYPTest.Room#getHvac <em>Hvac</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Hvac</em>'.
	 * @see fYPTest.Room#getHvac()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Hvac();

	/**
	 * Returns the meta object for class '{@link fYPTest.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sensor</em>'.
	 * @see fYPTest.Sensor
	 * @generated
	 */
	EClass getSensor();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Sensor#getSensorID <em>Sensor ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sensor ID</em>'.
	 * @see fYPTest.Sensor#getSensorID()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_SensorID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Sensor#getSensorType <em>Sensor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sensor Type</em>'.
	 * @see fYPTest.Sensor#getSensorType()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_SensorType();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Sensor#getTimeStamp <em>Time Stamp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time Stamp</em>'.
	 * @see fYPTest.Sensor#getTimeStamp()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_TimeStamp();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.Sensor#getRoomID <em>Room ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Room ID</em>'.
	 * @see fYPTest.Sensor#getRoomID()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_RoomID();

	/**
	 * Returns the meta object for the container reference '{@link fYPTest.Sensor#getRoom <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Room</em>'.
	 * @see fYPTest.Sensor#getRoom()
	 * @see #getSensor()
	 * @generated
	 */
	EReference getSensor_Room();

	/**
	 * Returns the meta object for class '{@link fYPTest.EnergyMeter <em>Energy Meter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Energy Meter</em>'.
	 * @see fYPTest.EnergyMeter
	 * @generated
	 */
	EClass getEnergyMeter();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.EnergyMeter#getEnergyConsumed <em>Energy Consumed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Energy Consumed</em>'.
	 * @see fYPTest.EnergyMeter#getEnergyConsumed()
	 * @see #getEnergyMeter()
	 * @generated
	 */
	EAttribute getEnergyMeter_EnergyConsumed();

	/**
	 * Returns the meta object for class '{@link fYPTest.TemperatureSensor <em>Temperature Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Temperature Sensor</em>'.
	 * @see fYPTest.TemperatureSensor
	 * @generated
	 */
	EClass getTemperatureSensor();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.TemperatureSensor#getTemperature <em>Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Temperature</em>'.
	 * @see fYPTest.TemperatureSensor#getTemperature()
	 * @see #getTemperatureSensor()
	 * @generated
	 */
	EAttribute getTemperatureSensor_Temperature();

	/**
	 * Returns the meta object for class '{@link fYPTest.HVACSystem <em>HVAC System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>HVAC System</em>'.
	 * @see fYPTest.HVACSystem
	 * @generated
	 */
	EClass getHVACSystem();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.HVACSystem#getHvacID <em>Hvac ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hvac ID</em>'.
	 * @see fYPTest.HVACSystem#getHvacID()
	 * @see #getHVACSystem()
	 * @generated
	 */
	EAttribute getHVACSystem_HvacID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.HVACSystem#getPowerUsage <em>Power Usage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Power Usage</em>'.
	 * @see fYPTest.HVACSystem#getPowerUsage()
	 * @see #getHVACSystem()
	 * @generated
	 */
	EAttribute getHVACSystem_PowerUsage();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.HVACSystem#isStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see fYPTest.HVACSystem#isStatus()
	 * @see #getHVACSystem()
	 * @generated
	 */
	EAttribute getHVACSystem_Status();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.HVACSystem#getLinkedRoom <em>Linked Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Linked Room</em>'.
	 * @see fYPTest.HVACSystem#getLinkedRoom()
	 * @see #getHVACSystem()
	 * @generated
	 */
	EAttribute getHVACSystem_LinkedRoom();

	/**
	 * Returns the meta object for the container reference '{@link fYPTest.HVACSystem#getRoom <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Room</em>'.
	 * @see fYPTest.HVACSystem#getRoom()
	 * @see #getHVACSystem()
	 * @generated
	 */
	EReference getHVACSystem_Room();

	/**
	 * Returns the meta object for class '{@link fYPTest.PredictiveModel <em>Predictive Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Predictive Model</em>'.
	 * @see fYPTest.PredictiveModel
	 * @generated
	 */
	EClass getPredictiveModel();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.PredictiveModel#getModelID <em>Model ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model ID</em>'.
	 * @see fYPTest.PredictiveModel#getModelID()
	 * @see #getPredictiveModel()
	 * @generated
	 */
	EAttribute getPredictiveModel_ModelID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.PredictiveModel#getModelType <em>Model Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model Type</em>'.
	 * @see fYPTest.PredictiveModel#getModelType()
	 * @see #getPredictiveModel()
	 * @generated
	 */
	EAttribute getPredictiveModel_ModelType();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.PredictiveModel#getInputVar <em>Input Var</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input Var</em>'.
	 * @see fYPTest.PredictiveModel#getInputVar()
	 * @see #getPredictiveModel()
	 * @generated
	 */
	EAttribute getPredictiveModel_InputVar();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.PredictiveModel#getOutputVar <em>Output Var</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output Var</em>'.
	 * @see fYPTest.PredictiveModel#getOutputVar()
	 * @see #getPredictiveModel()
	 * @generated
	 */
	EAttribute getPredictiveModel_OutputVar();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.PredictiveModel#getAccuracy <em>Accuracy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Accuracy</em>'.
	 * @see fYPTest.PredictiveModel#getAccuracy()
	 * @see #getPredictiveModel()
	 * @generated
	 */
	EAttribute getPredictiveModel_Accuracy();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.PredictiveModel#getLastTrained <em>Last Trained</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Trained</em>'.
	 * @see fYPTest.PredictiveModel#getLastTrained()
	 * @see #getPredictiveModel()
	 * @generated
	 */
	EAttribute getPredictiveModel_LastTrained();

	/**
	 * Returns the meta object for class '{@link fYPTest.DigitalTwin <em>Digital Twin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Digital Twin</em>'.
	 * @see fYPTest.DigitalTwin
	 * @generated
	 */
	EClass getDigitalTwin();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DigitalTwin#getTwinID <em>Twin ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Twin ID</em>'.
	 * @see fYPTest.DigitalTwin#getTwinID()
	 * @see #getDigitalTwin()
	 * @generated
	 */
	EAttribute getDigitalTwin_TwinID();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DigitalTwin#isStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see fYPTest.DigitalTwin#isStatus()
	 * @see #getDigitalTwin()
	 * @generated
	 */
	EAttribute getDigitalTwin_Status();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DigitalTwin#getLastUpdateTime <em>Last Update Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Update Time</em>'.
	 * @see fYPTest.DigitalTwin#getLastUpdateTime()
	 * @see #getDigitalTwin()
	 * @generated
	 */
	EAttribute getDigitalTwin_LastUpdateTime();

	/**
	 * Returns the meta object for the containment reference '{@link fYPTest.DigitalTwin#getPredictiveModel <em>Predictive Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Predictive Model</em>'.
	 * @see fYPTest.DigitalTwin#getPredictiveModel()
	 * @see #getDigitalTwin()
	 * @generated
	 */
	EReference getDigitalTwin_PredictiveModel();

	/**
	 * Returns the meta object for class '{@link fYPTest.DataManager <em>Data Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Data Manager</em>'.
	 * @see fYPTest.DataManager
	 * @generated
	 */
	EClass getDataManager();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DataManager#getDataSource <em>Data Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Source</em>'.
	 * @see fYPTest.DataManager#getDataSource()
	 * @see #getDataManager()
	 * @generated
	 */
	EAttribute getDataManager_DataSource();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DataManager#getUpdateInterval <em>Update Interval</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Update Interval</em>'.
	 * @see fYPTest.DataManager#getUpdateInterval()
	 * @see #getDataManager()
	 * @generated
	 */
	EAttribute getDataManager_UpdateInterval();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DataManager#getLastSync <em>Last Sync</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Sync</em>'.
	 * @see fYPTest.DataManager#getLastSync()
	 * @see #getDataManager()
	 * @generated
	 */
	EAttribute getDataManager_LastSync();

	/**
	 * Returns the meta object for the attribute '{@link fYPTest.DataManager#getStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see fYPTest.DataManager#getStatus()
	 * @see #getDataManager()
	 * @generated
	 */
	EAttribute getDataManager_Status();

	/**
	 * Returns the meta object for the reference list '{@link fYPTest.DataManager#getMonitorSensor <em>Monitor Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Monitor Sensor</em>'.
	 * @see fYPTest.DataManager#getMonitorSensor()
	 * @see #getDataManager()
	 * @generated
	 */
	EReference getDataManager_MonitorSensor();

	/**
	 * Returns the meta object for the reference '{@link fYPTest.DataManager#getPassData <em>Pass Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pass Data</em>'.
	 * @see fYPTest.DataManager#getPassData()
	 * @see #getDataManager()
	 * @generated
	 */
	EReference getDataManager_PassData();

	/**
	 * Returns the meta object for enum '{@link fYPTest.SensorType <em>Sensor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Sensor Type</em>'.
	 * @see fYPTest.SensorType
	 * @generated
	 */
	EEnum getSensorType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	FYPTestFactory getFYPTestFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link fYPTest.impl.BuildingImpl <em>Building</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.BuildingImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getBuilding()
		 * @generated
		 */
		EClass BUILDING = eINSTANCE.getBuilding();

		/**
		 * The meta object literal for the '<em><b>Building ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING__BUILDING_ID = eINSTANCE.getBuilding_BuildingID();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING__NAME = eINSTANCE.getBuilding_Name();

		/**
		 * The meta object literal for the '<em><b>Model3 DPath</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING__MODEL3_DPATH = eINSTANCE.getBuilding_Model3DPath();

		/**
		 * The meta object literal for the '<em><b>Floor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUILDING__FLOOR = eINSTANCE.getBuilding_Floor();

		/**
		 * The meta object literal for the '<em><b>Digital Twins</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUILDING__DIGITAL_TWINS = eINSTANCE.getBuilding_DigitalTwins();

		/**
		 * The meta object literal for the '<em><b>Owns</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUILDING__OWNS = eINSTANCE.getBuilding_Owns();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.FloorImpl <em>Floor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.FloorImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getFloor()
		 * @generated
		 */
		EClass FLOOR = eINSTANCE.getFloor();

		/**
		 * The meta object literal for the '<em><b>Floor ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLOOR__FLOOR_ID = eINSTANCE.getFloor_FloorID();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLOOR__AREA = eINSTANCE.getFloor_Area();

		/**
		 * The meta object literal for the '<em><b>Room</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FLOOR__ROOM = eINSTANCE.getFloor_Room();

		/**
		 * The meta object literal for the '<em><b>Building</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FLOOR__BUILDING = eINSTANCE.getFloor_Building();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.RoomImpl <em>Room</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.RoomImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getRoom()
		 * @generated
		 */
		EClass ROOM = eINSTANCE.getRoom();

		/**
		 * The meta object literal for the '<em><b>Room ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__ROOM_ID = eINSTANCE.getRoom_RoomID();

		/**
		 * The meta object literal for the '<em><b>Room Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__ROOM_NAME = eINSTANCE.getRoom_RoomName();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__AREA = eINSTANCE.getRoom_Area();

		/**
		 * The meta object literal for the '<em><b>Current Temp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__CURRENT_TEMP = eINSTANCE.getRoom_CurrentTemp();

		/**
		 * The meta object literal for the '<em><b>Energy Usage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__ENERGY_USAGE = eINSTANCE.getRoom_EnergyUsage();

		/**
		 * The meta object literal for the '<em><b>Sensors</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__SENSORS = eINSTANCE.getRoom_Sensors();

		/**
		 * The meta object literal for the '<em><b>Hvac</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__HVAC = eINSTANCE.getRoom_Hvac();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.SensorImpl <em>Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.SensorImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getSensor()
		 * @generated
		 */
		EClass SENSOR = eINSTANCE.getSensor();

		/**
		 * The meta object literal for the '<em><b>Sensor ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__SENSOR_ID = eINSTANCE.getSensor_SensorID();

		/**
		 * The meta object literal for the '<em><b>Sensor Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__SENSOR_TYPE = eINSTANCE.getSensor_SensorType();

		/**
		 * The meta object literal for the '<em><b>Time Stamp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__TIME_STAMP = eINSTANCE.getSensor_TimeStamp();

		/**
		 * The meta object literal for the '<em><b>Room ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__ROOM_ID = eINSTANCE.getSensor_RoomID();

		/**
		 * The meta object literal for the '<em><b>Room</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENSOR__ROOM = eINSTANCE.getSensor_Room();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.EnergyMeterImpl <em>Energy Meter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.EnergyMeterImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getEnergyMeter()
		 * @generated
		 */
		EClass ENERGY_METER = eINSTANCE.getEnergyMeter();

		/**
		 * The meta object literal for the '<em><b>Energy Consumed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENERGY_METER__ENERGY_CONSUMED = eINSTANCE.getEnergyMeter_EnergyConsumed();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.TemperatureSensorImpl <em>Temperature Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.TemperatureSensorImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getTemperatureSensor()
		 * @generated
		 */
		EClass TEMPERATURE_SENSOR = eINSTANCE.getTemperatureSensor();

		/**
		 * The meta object literal for the '<em><b>Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEMPERATURE_SENSOR__TEMPERATURE = eINSTANCE.getTemperatureSensor_Temperature();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.HVACSystemImpl <em>HVAC System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.HVACSystemImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getHVACSystem()
		 * @generated
		 */
		EClass HVAC_SYSTEM = eINSTANCE.getHVACSystem();

		/**
		 * The meta object literal for the '<em><b>Hvac ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HVAC_SYSTEM__HVAC_ID = eINSTANCE.getHVACSystem_HvacID();

		/**
		 * The meta object literal for the '<em><b>Power Usage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HVAC_SYSTEM__POWER_USAGE = eINSTANCE.getHVACSystem_PowerUsage();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HVAC_SYSTEM__STATUS = eINSTANCE.getHVACSystem_Status();

		/**
		 * The meta object literal for the '<em><b>Linked Room</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HVAC_SYSTEM__LINKED_ROOM = eINSTANCE.getHVACSystem_LinkedRoom();

		/**
		 * The meta object literal for the '<em><b>Room</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HVAC_SYSTEM__ROOM = eINSTANCE.getHVACSystem_Room();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.PredictiveModelImpl <em>Predictive Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.PredictiveModelImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getPredictiveModel()
		 * @generated
		 */
		EClass PREDICTIVE_MODEL = eINSTANCE.getPredictiveModel();

		/**
		 * The meta object literal for the '<em><b>Model ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTIVE_MODEL__MODEL_ID = eINSTANCE.getPredictiveModel_ModelID();

		/**
		 * The meta object literal for the '<em><b>Model Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTIVE_MODEL__MODEL_TYPE = eINSTANCE.getPredictiveModel_ModelType();

		/**
		 * The meta object literal for the '<em><b>Input Var</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTIVE_MODEL__INPUT_VAR = eINSTANCE.getPredictiveModel_InputVar();

		/**
		 * The meta object literal for the '<em><b>Output Var</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTIVE_MODEL__OUTPUT_VAR = eINSTANCE.getPredictiveModel_OutputVar();

		/**
		 * The meta object literal for the '<em><b>Accuracy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTIVE_MODEL__ACCURACY = eINSTANCE.getPredictiveModel_Accuracy();

		/**
		 * The meta object literal for the '<em><b>Last Trained</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTIVE_MODEL__LAST_TRAINED = eINSTANCE.getPredictiveModel_LastTrained();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.DigitalTwinImpl <em>Digital Twin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.DigitalTwinImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getDigitalTwin()
		 * @generated
		 */
		EClass DIGITAL_TWIN = eINSTANCE.getDigitalTwin();

		/**
		 * The meta object literal for the '<em><b>Twin ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIGITAL_TWIN__TWIN_ID = eINSTANCE.getDigitalTwin_TwinID();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIGITAL_TWIN__STATUS = eINSTANCE.getDigitalTwin_Status();

		/**
		 * The meta object literal for the '<em><b>Last Update Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIGITAL_TWIN__LAST_UPDATE_TIME = eINSTANCE.getDigitalTwin_LastUpdateTime();

		/**
		 * The meta object literal for the '<em><b>Predictive Model</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIGITAL_TWIN__PREDICTIVE_MODEL = eINSTANCE.getDigitalTwin_PredictiveModel();

		/**
		 * The meta object literal for the '{@link fYPTest.impl.DataManagerImpl <em>Data Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.impl.DataManagerImpl
		 * @see fYPTest.impl.FYPTestPackageImpl#getDataManager()
		 * @generated
		 */
		EClass DATA_MANAGER = eINSTANCE.getDataManager();

		/**
		 * The meta object literal for the '<em><b>Data Source</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_MANAGER__DATA_SOURCE = eINSTANCE.getDataManager_DataSource();

		/**
		 * The meta object literal for the '<em><b>Update Interval</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_MANAGER__UPDATE_INTERVAL = eINSTANCE.getDataManager_UpdateInterval();

		/**
		 * The meta object literal for the '<em><b>Last Sync</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_MANAGER__LAST_SYNC = eINSTANCE.getDataManager_LastSync();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_MANAGER__STATUS = eINSTANCE.getDataManager_Status();

		/**
		 * The meta object literal for the '<em><b>Monitor Sensor</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_MANAGER__MONITOR_SENSOR = eINSTANCE.getDataManager_MonitorSensor();

		/**
		 * The meta object literal for the '<em><b>Pass Data</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATA_MANAGER__PASS_DATA = eINSTANCE.getDataManager_PassData();

		/**
		 * The meta object literal for the '{@link fYPTest.SensorType <em>Sensor Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fYPTest.SensorType
		 * @see fYPTest.impl.FYPTestPackageImpl#getSensorType()
		 * @generated
		 */
		EEnum SENSOR_TYPE = eINSTANCE.getSensorType();

	}

} //FYPTestPackage
