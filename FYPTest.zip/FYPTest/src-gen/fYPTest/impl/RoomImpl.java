/**
 */
package fYPTest.impl;

import fYPTest.FYPTestPackage;
import fYPTest.HVACSystem;
import fYPTest.Room;
import fYPTest.Sensor;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.RoomImpl#getRoomID <em>Room ID</em>}</li>
 *   <li>{@link fYPTest.impl.RoomImpl#getRoomName <em>Room Name</em>}</li>
 *   <li>{@link fYPTest.impl.RoomImpl#getArea <em>Area</em>}</li>
 *   <li>{@link fYPTest.impl.RoomImpl#getCurrentTemp <em>Current Temp</em>}</li>
 *   <li>{@link fYPTest.impl.RoomImpl#getEnergyUsage <em>Energy Usage</em>}</li>
 *   <li>{@link fYPTest.impl.RoomImpl#getSensors <em>Sensors</em>}</li>
 *   <li>{@link fYPTest.impl.RoomImpl#getHvac <em>Hvac</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoomImpl extends MinimalEObjectImpl.Container implements Room {
	/**
	 * The default value of the '{@link #getRoomID() <em>Room ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoomID()
	 * @generated
	 * @ordered
	 */
	protected static final String ROOM_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRoomID() <em>Room ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoomID()
	 * @generated
	 * @ordered
	 */
	protected String roomID = ROOM_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getRoomName() <em>Room Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoomName()
	 * @generated
	 * @ordered
	 */
	protected static final String ROOM_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRoomName() <em>Room Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoomName()
	 * @generated
	 * @ordered
	 */
	protected String roomName = ROOM_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected static final double AREA_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected double area = AREA_EDEFAULT;

	/**
	 * The default value of the '{@link #getCurrentTemp() <em>Current Temp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentTemp()
	 * @generated
	 * @ordered
	 */
	protected static final double CURRENT_TEMP_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getCurrentTemp() <em>Current Temp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentTemp()
	 * @generated
	 * @ordered
	 */
	protected double currentTemp = CURRENT_TEMP_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnergyUsage() <em>Energy Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnergyUsage()
	 * @generated
	 * @ordered
	 */
	protected static final float ENERGY_USAGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getEnergyUsage() <em>Energy Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnergyUsage()
	 * @generated
	 * @ordered
	 */
	protected float energyUsage = ENERGY_USAGE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSensors() <em>Sensors</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensors()
	 * @generated
	 * @ordered
	 */
	protected EList<Sensor> sensors;

	/**
	 * The cached value of the '{@link #getHvac() <em>Hvac</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHvac()
	 * @generated
	 * @ordered
	 */
	protected HVACSystem hvac;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoomImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.ROOM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getRoomID() {
		return roomID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoomID(String newRoomID) {
		String oldRoomID = roomID;
		roomID = newRoomID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__ROOM_ID, oldRoomID, roomID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getRoomName() {
		return roomName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoomName(String newRoomName) {
		String oldRoomName = roomName;
		roomName = newRoomName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__ROOM_NAME, oldRoomName,
					roomName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getArea() {
		return area;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setArea(double newArea) {
		double oldArea = area;
		area = newArea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__AREA, oldArea, area));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getCurrentTemp() {
		return currentTemp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCurrentTemp(double newCurrentTemp) {
		double oldCurrentTemp = currentTemp;
		currentTemp = newCurrentTemp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__CURRENT_TEMP, oldCurrentTemp,
					currentTemp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getEnergyUsage() {
		return energyUsage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEnergyUsage(float newEnergyUsage) {
		float oldEnergyUsage = energyUsage;
		energyUsage = newEnergyUsage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__ENERGY_USAGE, oldEnergyUsage,
					energyUsage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Sensor> getSensors() {
		if (sensors == null) {
			sensors = new EObjectContainmentWithInverseEList<Sensor>(Sensor.class, this, FYPTestPackage.ROOM__SENSORS,
					FYPTestPackage.SENSOR__ROOM);
		}
		return sensors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HVACSystem getHvac() {
		return hvac;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHvac(HVACSystem newHvac, NotificationChain msgs) {
		HVACSystem oldHvac = hvac;
		hvac = newHvac;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__HVAC,
					oldHvac, newHvac);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHvac(HVACSystem newHvac) {
		if (newHvac != hvac) {
			NotificationChain msgs = null;
			if (hvac != null)
				msgs = ((InternalEObject) hvac).eInverseRemove(this, FYPTestPackage.HVAC_SYSTEM__ROOM, HVACSystem.class,
						msgs);
			if (newHvac != null)
				msgs = ((InternalEObject) newHvac).eInverseAdd(this, FYPTestPackage.HVAC_SYSTEM__ROOM, HVACSystem.class,
						msgs);
			msgs = basicSetHvac(newHvac, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ROOM__HVAC, newHvac, newHvac));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.ROOM__SENSORS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getSensors()).basicAdd(otherEnd, msgs);
		case FYPTestPackage.ROOM__HVAC:
			if (hvac != null)
				msgs = ((InternalEObject) hvac).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - FYPTestPackage.ROOM__HVAC,
						null, msgs);
			return basicSetHvac((HVACSystem) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.ROOM__SENSORS:
			return ((InternalEList<?>) getSensors()).basicRemove(otherEnd, msgs);
		case FYPTestPackage.ROOM__HVAC:
			return basicSetHvac(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.ROOM__ROOM_ID:
			return getRoomID();
		case FYPTestPackage.ROOM__ROOM_NAME:
			return getRoomName();
		case FYPTestPackage.ROOM__AREA:
			return getArea();
		case FYPTestPackage.ROOM__CURRENT_TEMP:
			return getCurrentTemp();
		case FYPTestPackage.ROOM__ENERGY_USAGE:
			return getEnergyUsage();
		case FYPTestPackage.ROOM__SENSORS:
			return getSensors();
		case FYPTestPackage.ROOM__HVAC:
			return getHvac();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.ROOM__ROOM_ID:
			setRoomID((String) newValue);
			return;
		case FYPTestPackage.ROOM__ROOM_NAME:
			setRoomName((String) newValue);
			return;
		case FYPTestPackage.ROOM__AREA:
			setArea((Double) newValue);
			return;
		case FYPTestPackage.ROOM__CURRENT_TEMP:
			setCurrentTemp((Double) newValue);
			return;
		case FYPTestPackage.ROOM__ENERGY_USAGE:
			setEnergyUsage((Float) newValue);
			return;
		case FYPTestPackage.ROOM__SENSORS:
			getSensors().clear();
			getSensors().addAll((Collection<? extends Sensor>) newValue);
			return;
		case FYPTestPackage.ROOM__HVAC:
			setHvac((HVACSystem) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.ROOM__ROOM_ID:
			setRoomID(ROOM_ID_EDEFAULT);
			return;
		case FYPTestPackage.ROOM__ROOM_NAME:
			setRoomName(ROOM_NAME_EDEFAULT);
			return;
		case FYPTestPackage.ROOM__AREA:
			setArea(AREA_EDEFAULT);
			return;
		case FYPTestPackage.ROOM__CURRENT_TEMP:
			setCurrentTemp(CURRENT_TEMP_EDEFAULT);
			return;
		case FYPTestPackage.ROOM__ENERGY_USAGE:
			setEnergyUsage(ENERGY_USAGE_EDEFAULT);
			return;
		case FYPTestPackage.ROOM__SENSORS:
			getSensors().clear();
			return;
		case FYPTestPackage.ROOM__HVAC:
			setHvac((HVACSystem) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.ROOM__ROOM_ID:
			return ROOM_ID_EDEFAULT == null ? roomID != null : !ROOM_ID_EDEFAULT.equals(roomID);
		case FYPTestPackage.ROOM__ROOM_NAME:
			return ROOM_NAME_EDEFAULT == null ? roomName != null : !ROOM_NAME_EDEFAULT.equals(roomName);
		case FYPTestPackage.ROOM__AREA:
			return area != AREA_EDEFAULT;
		case FYPTestPackage.ROOM__CURRENT_TEMP:
			return currentTemp != CURRENT_TEMP_EDEFAULT;
		case FYPTestPackage.ROOM__ENERGY_USAGE:
			return energyUsage != ENERGY_USAGE_EDEFAULT;
		case FYPTestPackage.ROOM__SENSORS:
			return sensors != null && !sensors.isEmpty();
		case FYPTestPackage.ROOM__HVAC:
			return hvac != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (roomID: ");
		result.append(roomID);
		result.append(", roomName: ");
		result.append(roomName);
		result.append(", area: ");
		result.append(area);
		result.append(", currentTemp: ");
		result.append(currentTemp);
		result.append(", energyUsage: ");
		result.append(energyUsage);
		result.append(')');
		return result.toString();
	}

} //RoomImpl
