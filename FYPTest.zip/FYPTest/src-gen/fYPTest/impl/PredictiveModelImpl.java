/**
 */
package fYPTest.impl;

import fYPTest.FYPTestPackage;
import fYPTest.PredictiveModel;

import java.util.Date;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Predictive Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.PredictiveModelImpl#getModelID <em>Model ID</em>}</li>
 *   <li>{@link fYPTest.impl.PredictiveModelImpl#getModelType <em>Model Type</em>}</li>
 *   <li>{@link fYPTest.impl.PredictiveModelImpl#getInputVar <em>Input Var</em>}</li>
 *   <li>{@link fYPTest.impl.PredictiveModelImpl#getOutputVar <em>Output Var</em>}</li>
 *   <li>{@link fYPTest.impl.PredictiveModelImpl#getAccuracy <em>Accuracy</em>}</li>
 *   <li>{@link fYPTest.impl.PredictiveModelImpl#getLastTrained <em>Last Trained</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PredictiveModelImpl extends MinimalEObjectImpl.Container implements PredictiveModel {
	/**
	 * The default value of the '{@link #getModelID() <em>Model ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelID()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModelID() <em>Model ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelID()
	 * @generated
	 * @ordered
	 */
	protected String modelID = MODEL_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getModelType() <em>Model Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelType()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModelType() <em>Model Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelType()
	 * @generated
	 * @ordered
	 */
	protected String modelType = MODEL_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getInputVar() <em>Input Var</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputVar()
	 * @generated
	 * @ordered
	 */
	protected static final String INPUT_VAR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInputVar() <em>Input Var</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputVar()
	 * @generated
	 * @ordered
	 */
	protected String inputVar = INPUT_VAR_EDEFAULT;

	/**
	 * The default value of the '{@link #getOutputVar() <em>Output Var</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputVar()
	 * @generated
	 * @ordered
	 */
	protected static final String OUTPUT_VAR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOutputVar() <em>Output Var</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputVar()
	 * @generated
	 * @ordered
	 */
	protected String outputVar = OUTPUT_VAR_EDEFAULT;

	/**
	 * The default value of the '{@link #getAccuracy() <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccuracy()
	 * @generated
	 * @ordered
	 */
	protected static final double ACCURACY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getAccuracy() <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccuracy()
	 * @generated
	 * @ordered
	 */
	protected double accuracy = ACCURACY_EDEFAULT;

	/**
	 * The default value of the '{@link #getLastTrained() <em>Last Trained</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastTrained()
	 * @generated
	 * @ordered
	 */
	protected static final Date LAST_TRAINED_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLastTrained() <em>Last Trained</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastTrained()
	 * @generated
	 * @ordered
	 */
	protected Date lastTrained = LAST_TRAINED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PredictiveModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.PREDICTIVE_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getModelID() {
		return modelID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setModelID(String newModelID) {
		String oldModelID = modelID;
		modelID = newModelID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.PREDICTIVE_MODEL__MODEL_ID, oldModelID,
					modelID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getModelType() {
		return modelType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setModelType(String newModelType) {
		String oldModelType = modelType;
		modelType = newModelType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.PREDICTIVE_MODEL__MODEL_TYPE,
					oldModelType, modelType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getInputVar() {
		return inputVar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInputVar(String newInputVar) {
		String oldInputVar = inputVar;
		inputVar = newInputVar;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.PREDICTIVE_MODEL__INPUT_VAR,
					oldInputVar, inputVar));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getOutputVar() {
		return outputVar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOutputVar(String newOutputVar) {
		String oldOutputVar = outputVar;
		outputVar = newOutputVar;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.PREDICTIVE_MODEL__OUTPUT_VAR,
					oldOutputVar, outputVar));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getAccuracy() {
		return accuracy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAccuracy(double newAccuracy) {
		double oldAccuracy = accuracy;
		accuracy = newAccuracy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.PREDICTIVE_MODEL__ACCURACY,
					oldAccuracy, accuracy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Date getLastTrained() {
		return lastTrained;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLastTrained(Date newLastTrained) {
		Date oldLastTrained = lastTrained;
		lastTrained = newLastTrained;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.PREDICTIVE_MODEL__LAST_TRAINED,
					oldLastTrained, lastTrained));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_ID:
			return getModelID();
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_TYPE:
			return getModelType();
		case FYPTestPackage.PREDICTIVE_MODEL__INPUT_VAR:
			return getInputVar();
		case FYPTestPackage.PREDICTIVE_MODEL__OUTPUT_VAR:
			return getOutputVar();
		case FYPTestPackage.PREDICTIVE_MODEL__ACCURACY:
			return getAccuracy();
		case FYPTestPackage.PREDICTIVE_MODEL__LAST_TRAINED:
			return getLastTrained();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_ID:
			setModelID((String) newValue);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_TYPE:
			setModelType((String) newValue);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__INPUT_VAR:
			setInputVar((String) newValue);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__OUTPUT_VAR:
			setOutputVar((String) newValue);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__ACCURACY:
			setAccuracy((Double) newValue);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__LAST_TRAINED:
			setLastTrained((Date) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_ID:
			setModelID(MODEL_ID_EDEFAULT);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_TYPE:
			setModelType(MODEL_TYPE_EDEFAULT);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__INPUT_VAR:
			setInputVar(INPUT_VAR_EDEFAULT);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__OUTPUT_VAR:
			setOutputVar(OUTPUT_VAR_EDEFAULT);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__ACCURACY:
			setAccuracy(ACCURACY_EDEFAULT);
			return;
		case FYPTestPackage.PREDICTIVE_MODEL__LAST_TRAINED:
			setLastTrained(LAST_TRAINED_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_ID:
			return MODEL_ID_EDEFAULT == null ? modelID != null : !MODEL_ID_EDEFAULT.equals(modelID);
		case FYPTestPackage.PREDICTIVE_MODEL__MODEL_TYPE:
			return MODEL_TYPE_EDEFAULT == null ? modelType != null : !MODEL_TYPE_EDEFAULT.equals(modelType);
		case FYPTestPackage.PREDICTIVE_MODEL__INPUT_VAR:
			return INPUT_VAR_EDEFAULT == null ? inputVar != null : !INPUT_VAR_EDEFAULT.equals(inputVar);
		case FYPTestPackage.PREDICTIVE_MODEL__OUTPUT_VAR:
			return OUTPUT_VAR_EDEFAULT == null ? outputVar != null : !OUTPUT_VAR_EDEFAULT.equals(outputVar);
		case FYPTestPackage.PREDICTIVE_MODEL__ACCURACY:
			return accuracy != ACCURACY_EDEFAULT;
		case FYPTestPackage.PREDICTIVE_MODEL__LAST_TRAINED:
			return LAST_TRAINED_EDEFAULT == null ? lastTrained != null : !LAST_TRAINED_EDEFAULT.equals(lastTrained);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (modelID: ");
		result.append(modelID);
		result.append(", modelType: ");
		result.append(modelType);
		result.append(", inputVar: ");
		result.append(inputVar);
		result.append(", outputVar: ");
		result.append(outputVar);
		result.append(", accuracy: ");
		result.append(accuracy);
		result.append(", lastTrained: ");
		result.append(lastTrained);
		result.append(')');
		return result.toString();
	}

} //PredictiveModelImpl
