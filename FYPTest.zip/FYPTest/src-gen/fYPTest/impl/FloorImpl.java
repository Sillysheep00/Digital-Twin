/**
 */
package fYPTest.impl;

import fYPTest.Building;
import fYPTest.FYPTestPackage;
import fYPTest.Floor;
import fYPTest.Room;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Floor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.FloorImpl#getFloorID <em>Floor ID</em>}</li>
 *   <li>{@link fYPTest.impl.FloorImpl#getArea <em>Area</em>}</li>
 *   <li>{@link fYPTest.impl.FloorImpl#getRoom <em>Room</em>}</li>
 *   <li>{@link fYPTest.impl.FloorImpl#getBuilding <em>Building</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FloorImpl extends MinimalEObjectImpl.Container implements Floor {
	/**
	 * The default value of the '{@link #getFloorID() <em>Floor ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloorID()
	 * @generated
	 * @ordered
	 */
	protected static final String FLOOR_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFloorID() <em>Floor ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloorID()
	 * @generated
	 * @ordered
	 */
	protected String floorID = FLOOR_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected static final double AREA_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected double area = AREA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRoom() <em>Room</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoom()
	 * @generated
	 * @ordered
	 */
	protected EList<Room> room;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FloorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.FLOOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFloorID() {
		return floorID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFloorID(String newFloorID) {
		String oldFloorID = floorID;
		floorID = newFloorID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.FLOOR__FLOOR_ID, oldFloorID, floorID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getArea() {
		return area;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setArea(double newArea) {
		double oldArea = area;
		area = newArea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.FLOOR__AREA, oldArea, area));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Room> getRoom() {
		if (room == null) {
			room = new EObjectContainmentEList<Room>(Room.class, this, FYPTestPackage.FLOOR__ROOM);
		}
		return room;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Building getBuilding() {
		if (eContainerFeatureID() != FYPTestPackage.FLOOR__BUILDING)
			return null;
		return (Building) eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuilding(Building newBuilding, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject) newBuilding, FYPTestPackage.FLOOR__BUILDING, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBuilding(Building newBuilding) {
		if (newBuilding != eInternalContainer()
				|| (eContainerFeatureID() != FYPTestPackage.FLOOR__BUILDING && newBuilding != null)) {
			if (EcoreUtil.isAncestor(this, newBuilding))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newBuilding != null)
				msgs = ((InternalEObject) newBuilding).eInverseAdd(this, FYPTestPackage.BUILDING__FLOOR, Building.class,
						msgs);
			msgs = basicSetBuilding(newBuilding, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.FLOOR__BUILDING, newBuilding,
					newBuilding));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.FLOOR__BUILDING:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetBuilding((Building) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.FLOOR__ROOM:
			return ((InternalEList<?>) getRoom()).basicRemove(otherEnd, msgs);
		case FYPTestPackage.FLOOR__BUILDING:
			return basicSetBuilding(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
		case FYPTestPackage.FLOOR__BUILDING:
			return eInternalContainer().eInverseRemove(this, FYPTestPackage.BUILDING__FLOOR, Building.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.FLOOR__FLOOR_ID:
			return getFloorID();
		case FYPTestPackage.FLOOR__AREA:
			return getArea();
		case FYPTestPackage.FLOOR__ROOM:
			return getRoom();
		case FYPTestPackage.FLOOR__BUILDING:
			return getBuilding();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.FLOOR__FLOOR_ID:
			setFloorID((String) newValue);
			return;
		case FYPTestPackage.FLOOR__AREA:
			setArea((Double) newValue);
			return;
		case FYPTestPackage.FLOOR__ROOM:
			getRoom().clear();
			getRoom().addAll((Collection<? extends Room>) newValue);
			return;
		case FYPTestPackage.FLOOR__BUILDING:
			setBuilding((Building) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.FLOOR__FLOOR_ID:
			setFloorID(FLOOR_ID_EDEFAULT);
			return;
		case FYPTestPackage.FLOOR__AREA:
			setArea(AREA_EDEFAULT);
			return;
		case FYPTestPackage.FLOOR__ROOM:
			getRoom().clear();
			return;
		case FYPTestPackage.FLOOR__BUILDING:
			setBuilding((Building) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.FLOOR__FLOOR_ID:
			return FLOOR_ID_EDEFAULT == null ? floorID != null : !FLOOR_ID_EDEFAULT.equals(floorID);
		case FYPTestPackage.FLOOR__AREA:
			return area != AREA_EDEFAULT;
		case FYPTestPackage.FLOOR__ROOM:
			return room != null && !room.isEmpty();
		case FYPTestPackage.FLOOR__BUILDING:
			return getBuilding() != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (floorID: ");
		result.append(floorID);
		result.append(", area: ");
		result.append(area);
		result.append(')');
		return result.toString();
	}

} //FloorImpl
