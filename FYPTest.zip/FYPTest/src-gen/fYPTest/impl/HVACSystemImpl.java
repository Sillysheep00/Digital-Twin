/**
 */
package fYPTest.impl;

import fYPTest.FYPTestPackage;
import fYPTest.HVACSystem;
import fYPTest.Room;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>HVAC System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.HVACSystemImpl#getHvacID <em>Hvac ID</em>}</li>
 *   <li>{@link fYPTest.impl.HVACSystemImpl#getPowerUsage <em>Power Usage</em>}</li>
 *   <li>{@link fYPTest.impl.HVACSystemImpl#isStatus <em>Status</em>}</li>
 *   <li>{@link fYPTest.impl.HVACSystemImpl#getLinkedRoom <em>Linked Room</em>}</li>
 *   <li>{@link fYPTest.impl.HVACSystemImpl#getRoom <em>Room</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HVACSystemImpl extends MinimalEObjectImpl.Container implements HVACSystem {
	/**
	 * The default value of the '{@link #getHvacID() <em>Hvac ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHvacID()
	 * @generated
	 * @ordered
	 */
	protected static final String HVAC_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHvacID() <em>Hvac ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHvacID()
	 * @generated
	 * @ordered
	 */
	protected String hvacID = HVAC_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getPowerUsage() <em>Power Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPowerUsage()
	 * @generated
	 * @ordered
	 */
	protected static final float POWER_USAGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPowerUsage() <em>Power Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPowerUsage()
	 * @generated
	 * @ordered
	 */
	protected float powerUsage = POWER_USAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean status = STATUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getLinkedRoom() <em>Linked Room</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinkedRoom()
	 * @generated
	 * @ordered
	 */
	protected static final String LINKED_ROOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLinkedRoom() <em>Linked Room</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinkedRoom()
	 * @generated
	 * @ordered
	 */
	protected String linkedRoom = LINKED_ROOM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HVACSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.HVAC_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getHvacID() {
		return hvacID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHvacID(String newHvacID) {
		String oldHvacID = hvacID;
		hvacID = newHvacID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.HVAC_SYSTEM__HVAC_ID, oldHvacID,
					hvacID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getPowerUsage() {
		return powerUsage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPowerUsage(float newPowerUsage) {
		float oldPowerUsage = powerUsage;
		powerUsage = newPowerUsage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.HVAC_SYSTEM__POWER_USAGE,
					oldPowerUsage, powerUsage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(boolean newStatus) {
		boolean oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.HVAC_SYSTEM__STATUS, oldStatus,
					status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLinkedRoom() {
		return linkedRoom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLinkedRoom(String newLinkedRoom) {
		String oldLinkedRoom = linkedRoom;
		linkedRoom = newLinkedRoom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.HVAC_SYSTEM__LINKED_ROOM,
					oldLinkedRoom, linkedRoom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Room getRoom() {
		if (eContainerFeatureID() != FYPTestPackage.HVAC_SYSTEM__ROOM)
			return null;
		return (Room) eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRoom(Room newRoom, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject) newRoom, FYPTestPackage.HVAC_SYSTEM__ROOM, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoom(Room newRoom) {
		if (newRoom != eInternalContainer()
				|| (eContainerFeatureID() != FYPTestPackage.HVAC_SYSTEM__ROOM && newRoom != null)) {
			if (EcoreUtil.isAncestor(this, newRoom))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newRoom != null)
				msgs = ((InternalEObject) newRoom).eInverseAdd(this, FYPTestPackage.ROOM__HVAC, Room.class, msgs);
			msgs = basicSetRoom(newRoom, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.HVAC_SYSTEM__ROOM, newRoom, newRoom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetRoom((Room) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			return basicSetRoom(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			return eInternalContainer().eInverseRemove(this, FYPTestPackage.ROOM__HVAC, Room.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.HVAC_SYSTEM__HVAC_ID:
			return getHvacID();
		case FYPTestPackage.HVAC_SYSTEM__POWER_USAGE:
			return getPowerUsage();
		case FYPTestPackage.HVAC_SYSTEM__STATUS:
			return isStatus();
		case FYPTestPackage.HVAC_SYSTEM__LINKED_ROOM:
			return getLinkedRoom();
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			return getRoom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.HVAC_SYSTEM__HVAC_ID:
			setHvacID((String) newValue);
			return;
		case FYPTestPackage.HVAC_SYSTEM__POWER_USAGE:
			setPowerUsage((Float) newValue);
			return;
		case FYPTestPackage.HVAC_SYSTEM__STATUS:
			setStatus((Boolean) newValue);
			return;
		case FYPTestPackage.HVAC_SYSTEM__LINKED_ROOM:
			setLinkedRoom((String) newValue);
			return;
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			setRoom((Room) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.HVAC_SYSTEM__HVAC_ID:
			setHvacID(HVAC_ID_EDEFAULT);
			return;
		case FYPTestPackage.HVAC_SYSTEM__POWER_USAGE:
			setPowerUsage(POWER_USAGE_EDEFAULT);
			return;
		case FYPTestPackage.HVAC_SYSTEM__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		case FYPTestPackage.HVAC_SYSTEM__LINKED_ROOM:
			setLinkedRoom(LINKED_ROOM_EDEFAULT);
			return;
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			setRoom((Room) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.HVAC_SYSTEM__HVAC_ID:
			return HVAC_ID_EDEFAULT == null ? hvacID != null : !HVAC_ID_EDEFAULT.equals(hvacID);
		case FYPTestPackage.HVAC_SYSTEM__POWER_USAGE:
			return powerUsage != POWER_USAGE_EDEFAULT;
		case FYPTestPackage.HVAC_SYSTEM__STATUS:
			return status != STATUS_EDEFAULT;
		case FYPTestPackage.HVAC_SYSTEM__LINKED_ROOM:
			return LINKED_ROOM_EDEFAULT == null ? linkedRoom != null : !LINKED_ROOM_EDEFAULT.equals(linkedRoom);
		case FYPTestPackage.HVAC_SYSTEM__ROOM:
			return getRoom() != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (hvacID: ");
		result.append(hvacID);
		result.append(", powerUsage: ");
		result.append(powerUsage);
		result.append(", status: ");
		result.append(status);
		result.append(", linkedRoom: ");
		result.append(linkedRoom);
		result.append(')');
		return result.toString();
	}

} //HVACSystemImpl
