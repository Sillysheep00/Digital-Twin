/**
 */
package fYPTest.impl;

import fYPTest.EnergyMeter;
import fYPTest.FYPTestPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Energy Meter</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.EnergyMeterImpl#getEnergyConsumed <em>Energy Consumed</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EnergyMeterImpl extends SensorImpl implements EnergyMeter {
	/**
	 * The default value of the '{@link #getEnergyConsumed() <em>Energy Consumed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnergyConsumed()
	 * @generated
	 * @ordered
	 */
	protected static final double ENERGY_CONSUMED_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getEnergyConsumed() <em>Energy Consumed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnergyConsumed()
	 * @generated
	 * @ordered
	 */
	protected double energyConsumed = ENERGY_CONSUMED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EnergyMeterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.ENERGY_METER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getEnergyConsumed() {
		return energyConsumed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEnergyConsumed(double newEnergyConsumed) {
		double oldEnergyConsumed = energyConsumed;
		energyConsumed = newEnergyConsumed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.ENERGY_METER__ENERGY_CONSUMED,
					oldEnergyConsumed, energyConsumed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.ENERGY_METER__ENERGY_CONSUMED:
			return getEnergyConsumed();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.ENERGY_METER__ENERGY_CONSUMED:
			setEnergyConsumed((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.ENERGY_METER__ENERGY_CONSUMED:
			setEnergyConsumed(ENERGY_CONSUMED_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.ENERGY_METER__ENERGY_CONSUMED:
			return energyConsumed != ENERGY_CONSUMED_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (energyConsumed: ");
		result.append(energyConsumed);
		result.append(')');
		return result.toString();
	}

} //EnergyMeterImpl
