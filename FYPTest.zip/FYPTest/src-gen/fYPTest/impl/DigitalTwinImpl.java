/**
 */
package fYPTest.impl;

import fYPTest.DigitalTwin;
import fYPTest.FYPTestPackage;
import fYPTest.PredictiveModel;

import java.util.Date;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Digital Twin</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.DigitalTwinImpl#getTwinID <em>Twin ID</em>}</li>
 *   <li>{@link fYPTest.impl.DigitalTwinImpl#isStatus <em>Status</em>}</li>
 *   <li>{@link fYPTest.impl.DigitalTwinImpl#getLastUpdateTime <em>Last Update Time</em>}</li>
 *   <li>{@link fYPTest.impl.DigitalTwinImpl#getPredictiveModel <em>Predictive Model</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DigitalTwinImpl extends MinimalEObjectImpl.Container implements DigitalTwin {
	/**
	 * The default value of the '{@link #getTwinID() <em>Twin ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTwinID()
	 * @generated
	 * @ordered
	 */
	protected static final String TWIN_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTwinID() <em>Twin ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTwinID()
	 * @generated
	 * @ordered
	 */
	protected String twinID = TWIN_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean status = STATUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getLastUpdateTime() <em>Last Update Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastUpdateTime()
	 * @generated
	 * @ordered
	 */
	protected static final Date LAST_UPDATE_TIME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLastUpdateTime() <em>Last Update Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastUpdateTime()
	 * @generated
	 * @ordered
	 */
	protected Date lastUpdateTime = LAST_UPDATE_TIME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPredictiveModel() <em>Predictive Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPredictiveModel()
	 * @generated
	 * @ordered
	 */
	protected PredictiveModel predictiveModel;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DigitalTwinImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.DIGITAL_TWIN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTwinID() {
		return twinID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTwinID(String newTwinID) {
		String oldTwinID = twinID;
		twinID = newTwinID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DIGITAL_TWIN__TWIN_ID, oldTwinID,
					twinID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(boolean newStatus) {
		boolean oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DIGITAL_TWIN__STATUS, oldStatus,
					status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLastUpdateTime(Date newLastUpdateTime) {
		Date oldLastUpdateTime = lastUpdateTime;
		lastUpdateTime = newLastUpdateTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DIGITAL_TWIN__LAST_UPDATE_TIME,
					oldLastUpdateTime, lastUpdateTime));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PredictiveModel getPredictiveModel() {
		return predictiveModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPredictiveModel(PredictiveModel newPredictiveModel, NotificationChain msgs) {
		PredictiveModel oldPredictiveModel = predictiveModel;
		predictiveModel = newPredictiveModel;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL, oldPredictiveModel, newPredictiveModel);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPredictiveModel(PredictiveModel newPredictiveModel) {
		if (newPredictiveModel != predictiveModel) {
			NotificationChain msgs = null;
			if (predictiveModel != null)
				msgs = ((InternalEObject) predictiveModel).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL, null, msgs);
			if (newPredictiveModel != null)
				msgs = ((InternalEObject) newPredictiveModel).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL, null, msgs);
			msgs = basicSetPredictiveModel(newPredictiveModel, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL,
					newPredictiveModel, newPredictiveModel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL:
			return basicSetPredictiveModel(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.DIGITAL_TWIN__TWIN_ID:
			return getTwinID();
		case FYPTestPackage.DIGITAL_TWIN__STATUS:
			return isStatus();
		case FYPTestPackage.DIGITAL_TWIN__LAST_UPDATE_TIME:
			return getLastUpdateTime();
		case FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL:
			return getPredictiveModel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.DIGITAL_TWIN__TWIN_ID:
			setTwinID((String) newValue);
			return;
		case FYPTestPackage.DIGITAL_TWIN__STATUS:
			setStatus((Boolean) newValue);
			return;
		case FYPTestPackage.DIGITAL_TWIN__LAST_UPDATE_TIME:
			setLastUpdateTime((Date) newValue);
			return;
		case FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL:
			setPredictiveModel((PredictiveModel) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.DIGITAL_TWIN__TWIN_ID:
			setTwinID(TWIN_ID_EDEFAULT);
			return;
		case FYPTestPackage.DIGITAL_TWIN__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		case FYPTestPackage.DIGITAL_TWIN__LAST_UPDATE_TIME:
			setLastUpdateTime(LAST_UPDATE_TIME_EDEFAULT);
			return;
		case FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL:
			setPredictiveModel((PredictiveModel) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.DIGITAL_TWIN__TWIN_ID:
			return TWIN_ID_EDEFAULT == null ? twinID != null : !TWIN_ID_EDEFAULT.equals(twinID);
		case FYPTestPackage.DIGITAL_TWIN__STATUS:
			return status != STATUS_EDEFAULT;
		case FYPTestPackage.DIGITAL_TWIN__LAST_UPDATE_TIME:
			return LAST_UPDATE_TIME_EDEFAULT == null ? lastUpdateTime != null
					: !LAST_UPDATE_TIME_EDEFAULT.equals(lastUpdateTime);
		case FYPTestPackage.DIGITAL_TWIN__PREDICTIVE_MODEL:
			return predictiveModel != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (twinID: ");
		result.append(twinID);
		result.append(", status: ");
		result.append(status);
		result.append(", lastUpdateTime: ");
		result.append(lastUpdateTime);
		result.append(')');
		return result.toString();
	}

} //DigitalTwinImpl
