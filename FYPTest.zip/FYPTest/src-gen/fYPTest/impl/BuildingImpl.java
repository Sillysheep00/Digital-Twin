/**
 */
package fYPTest.impl;

import fYPTest.Building;
import fYPTest.DataManager;
import fYPTest.DigitalTwin;
import fYPTest.FYPTestPackage;
import fYPTest.Floor;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Building</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.BuildingImpl#getBuildingID <em>Building ID</em>}</li>
 *   <li>{@link fYPTest.impl.BuildingImpl#getName <em>Name</em>}</li>
 *   <li>{@link fYPTest.impl.BuildingImpl#getModel3DPath <em>Model3 DPath</em>}</li>
 *   <li>{@link fYPTest.impl.BuildingImpl#getFloor <em>Floor</em>}</li>
 *   <li>{@link fYPTest.impl.BuildingImpl#getDigitalTwins <em>Digital Twins</em>}</li>
 *   <li>{@link fYPTest.impl.BuildingImpl#getOwns <em>Owns</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BuildingImpl extends MinimalEObjectImpl.Container implements Building {
	/**
	 * The default value of the '{@link #getBuildingID() <em>Building ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuildingID()
	 * @generated
	 * @ordered
	 */
	protected static final String BUILDING_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBuildingID() <em>Building ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuildingID()
	 * @generated
	 * @ordered
	 */
	protected String buildingID = BUILDING_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getModel3DPath() <em>Model3 DPath</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel3DPath()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL3_DPATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModel3DPath() <em>Model3 DPath</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel3DPath()
	 * @generated
	 * @ordered
	 */
	protected String model3DPath = MODEL3_DPATH_EDEFAULT;

	/**
	 * The cached value of the '{@link #getFloor() <em>Floor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFloor()
	 * @generated
	 * @ordered
	 */
	protected EList<Floor> floor;

	/**
	 * The cached value of the '{@link #getDigitalTwins() <em>Digital Twins</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDigitalTwins()
	 * @generated
	 * @ordered
	 */
	protected DigitalTwin digitalTwins;

	/**
	 * The cached value of the '{@link #getOwns() <em>Owns</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwns()
	 * @generated
	 * @ordered
	 */
	protected DataManager owns;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BuildingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.BUILDING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getBuildingID() {
		return buildingID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBuildingID(String newBuildingID) {
		String oldBuildingID = buildingID;
		buildingID = newBuildingID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.BUILDING__BUILDING_ID, oldBuildingID,
					buildingID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.BUILDING__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getModel3DPath() {
		return model3DPath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setModel3DPath(String newModel3DPath) {
		String oldModel3DPath = model3DPath;
		model3DPath = newModel3DPath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.BUILDING__MODEL3_DPATH, oldModel3DPath,
					model3DPath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Floor> getFloor() {
		if (floor == null) {
			floor = new EObjectContainmentWithInverseEList<Floor>(Floor.class, this, FYPTestPackage.BUILDING__FLOOR,
					FYPTestPackage.FLOOR__BUILDING);
		}
		return floor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DigitalTwin getDigitalTwins() {
		return digitalTwins;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDigitalTwins(DigitalTwin newDigitalTwins, NotificationChain msgs) {
		DigitalTwin oldDigitalTwins = digitalTwins;
		digitalTwins = newDigitalTwins;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					FYPTestPackage.BUILDING__DIGITAL_TWINS, oldDigitalTwins, newDigitalTwins);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDigitalTwins(DigitalTwin newDigitalTwins) {
		if (newDigitalTwins != digitalTwins) {
			NotificationChain msgs = null;
			if (digitalTwins != null)
				msgs = ((InternalEObject) digitalTwins).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - FYPTestPackage.BUILDING__DIGITAL_TWINS, null, msgs);
			if (newDigitalTwins != null)
				msgs = ((InternalEObject) newDigitalTwins).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - FYPTestPackage.BUILDING__DIGITAL_TWINS, null, msgs);
			msgs = basicSetDigitalTwins(newDigitalTwins, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.BUILDING__DIGITAL_TWINS,
					newDigitalTwins, newDigitalTwins));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DataManager getOwns() {
		return owns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOwns(DataManager newOwns, NotificationChain msgs) {
		DataManager oldOwns = owns;
		owns = newOwns;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					FYPTestPackage.BUILDING__OWNS, oldOwns, newOwns);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOwns(DataManager newOwns) {
		if (newOwns != owns) {
			NotificationChain msgs = null;
			if (owns != null)
				msgs = ((InternalEObject) owns).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - FYPTestPackage.BUILDING__OWNS, null, msgs);
			if (newOwns != null)
				msgs = ((InternalEObject) newOwns).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - FYPTestPackage.BUILDING__OWNS, null, msgs);
			msgs = basicSetOwns(newOwns, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.BUILDING__OWNS, newOwns, newOwns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.BUILDING__FLOOR:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getFloor()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FYPTestPackage.BUILDING__FLOOR:
			return ((InternalEList<?>) getFloor()).basicRemove(otherEnd, msgs);
		case FYPTestPackage.BUILDING__DIGITAL_TWINS:
			return basicSetDigitalTwins(null, msgs);
		case FYPTestPackage.BUILDING__OWNS:
			return basicSetOwns(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.BUILDING__BUILDING_ID:
			return getBuildingID();
		case FYPTestPackage.BUILDING__NAME:
			return getName();
		case FYPTestPackage.BUILDING__MODEL3_DPATH:
			return getModel3DPath();
		case FYPTestPackage.BUILDING__FLOOR:
			return getFloor();
		case FYPTestPackage.BUILDING__DIGITAL_TWINS:
			return getDigitalTwins();
		case FYPTestPackage.BUILDING__OWNS:
			return getOwns();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.BUILDING__BUILDING_ID:
			setBuildingID((String) newValue);
			return;
		case FYPTestPackage.BUILDING__NAME:
			setName((String) newValue);
			return;
		case FYPTestPackage.BUILDING__MODEL3_DPATH:
			setModel3DPath((String) newValue);
			return;
		case FYPTestPackage.BUILDING__FLOOR:
			getFloor().clear();
			getFloor().addAll((Collection<? extends Floor>) newValue);
			return;
		case FYPTestPackage.BUILDING__DIGITAL_TWINS:
			setDigitalTwins((DigitalTwin) newValue);
			return;
		case FYPTestPackage.BUILDING__OWNS:
			setOwns((DataManager) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.BUILDING__BUILDING_ID:
			setBuildingID(BUILDING_ID_EDEFAULT);
			return;
		case FYPTestPackage.BUILDING__NAME:
			setName(NAME_EDEFAULT);
			return;
		case FYPTestPackage.BUILDING__MODEL3_DPATH:
			setModel3DPath(MODEL3_DPATH_EDEFAULT);
			return;
		case FYPTestPackage.BUILDING__FLOOR:
			getFloor().clear();
			return;
		case FYPTestPackage.BUILDING__DIGITAL_TWINS:
			setDigitalTwins((DigitalTwin) null);
			return;
		case FYPTestPackage.BUILDING__OWNS:
			setOwns((DataManager) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.BUILDING__BUILDING_ID:
			return BUILDING_ID_EDEFAULT == null ? buildingID != null : !BUILDING_ID_EDEFAULT.equals(buildingID);
		case FYPTestPackage.BUILDING__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case FYPTestPackage.BUILDING__MODEL3_DPATH:
			return MODEL3_DPATH_EDEFAULT == null ? model3DPath != null : !MODEL3_DPATH_EDEFAULT.equals(model3DPath);
		case FYPTestPackage.BUILDING__FLOOR:
			return floor != null && !floor.isEmpty();
		case FYPTestPackage.BUILDING__DIGITAL_TWINS:
			return digitalTwins != null;
		case FYPTestPackage.BUILDING__OWNS:
			return owns != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (buildingID: ");
		result.append(buildingID);
		result.append(", name: ");
		result.append(name);
		result.append(", model3DPath: ");
		result.append(model3DPath);
		result.append(')');
		return result.toString();
	}

} //BuildingImpl
