/**
 */
package fYPTest.impl;

import fYPTest.DataManager;
import fYPTest.DigitalTwin;
import fYPTest.FYPTestPackage;
import fYPTest.Sensor;
import java.util.Collection;
import java.util.Date;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Data Manager</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.impl.DataManagerImpl#getDataSource <em>Data Source</em>}</li>
 *   <li>{@link fYPTest.impl.DataManagerImpl#getUpdateInterval <em>Update Interval</em>}</li>
 *   <li>{@link fYPTest.impl.DataManagerImpl#getLastSync <em>Last Sync</em>}</li>
 *   <li>{@link fYPTest.impl.DataManagerImpl#getStatus <em>Status</em>}</li>
 *   <li>{@link fYPTest.impl.DataManagerImpl#getMonitorSensor <em>Monitor Sensor</em>}</li>
 *   <li>{@link fYPTest.impl.DataManagerImpl#getPassData <em>Pass Data</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DataManagerImpl extends MinimalEObjectImpl.Container implements DataManager {
	/**
	 * The default value of the '{@link #getDataSource() <em>Data Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataSource()
	 * @generated
	 * @ordered
	 */
	protected static final String DATA_SOURCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataSource() <em>Data Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataSource()
	 * @generated
	 * @ordered
	 */
	protected String dataSource = DATA_SOURCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getUpdateInterval() <em>Update Interval</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUpdateInterval()
	 * @generated
	 * @ordered
	 */
	protected static final int UPDATE_INTERVAL_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getUpdateInterval() <em>Update Interval</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUpdateInterval()
	 * @generated
	 * @ordered
	 */
	protected int updateInterval = UPDATE_INTERVAL_EDEFAULT;

	/**
	 * The default value of the '{@link #getLastSync() <em>Last Sync</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastSync()
	 * @generated
	 * @ordered
	 */
	protected static final Date LAST_SYNC_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLastSync() <em>Last Sync</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastSync()
	 * @generated
	 * @ordered
	 */
	protected Date lastSync = LAST_SYNC_EDEFAULT;

	/**
	 * The default value of the '{@link #getStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatus()
	 * @generated
	 * @ordered
	 */
	protected static final String STATUS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatus()
	 * @generated
	 * @ordered
	 */
	protected String status = STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMonitorSensor() <em>Monitor Sensor</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitorSensor()
	 * @generated
	 * @ordered
	 */
	protected EList<Sensor> monitorSensor;

	/**
	 * The cached value of the '{@link #getPassData() <em>Pass Data</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPassData()
	 * @generated
	 * @ordered
	 */
	protected DigitalTwin passData;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DataManagerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FYPTestPackage.Literals.DATA_MANAGER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getDataSource() {
		return dataSource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDataSource(String newDataSource) {
		String oldDataSource = dataSource;
		dataSource = newDataSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DATA_MANAGER__DATA_SOURCE,
					oldDataSource, dataSource));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getUpdateInterval() {
		return updateInterval;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setUpdateInterval(int newUpdateInterval) {
		int oldUpdateInterval = updateInterval;
		updateInterval = newUpdateInterval;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DATA_MANAGER__UPDATE_INTERVAL,
					oldUpdateInterval, updateInterval));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Date getLastSync() {
		return lastSync;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLastSync(Date newLastSync) {
		Date oldLastSync = lastSync;
		lastSync = newLastSync;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DATA_MANAGER__LAST_SYNC, oldLastSync,
					lastSync));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(String newStatus) {
		String oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DATA_MANAGER__STATUS, oldStatus,
					status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Sensor> getMonitorSensor() {
		if (monitorSensor == null) {
			monitorSensor = new EObjectResolvingEList<Sensor>(Sensor.class, this,
					FYPTestPackage.DATA_MANAGER__MONITOR_SENSOR);
		}
		return monitorSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DigitalTwin getPassData() {
		if (passData != null && passData.eIsProxy()) {
			InternalEObject oldPassData = (InternalEObject) passData;
			passData = (DigitalTwin) eResolveProxy(oldPassData);
			if (passData != oldPassData) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, FYPTestPackage.DATA_MANAGER__PASS_DATA,
							oldPassData, passData));
			}
		}
		return passData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DigitalTwin basicGetPassData() {
		return passData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPassData(DigitalTwin newPassData) {
		DigitalTwin oldPassData = passData;
		passData = newPassData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FYPTestPackage.DATA_MANAGER__PASS_DATA, oldPassData,
					passData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FYPTestPackage.DATA_MANAGER__DATA_SOURCE:
			return getDataSource();
		case FYPTestPackage.DATA_MANAGER__UPDATE_INTERVAL:
			return getUpdateInterval();
		case FYPTestPackage.DATA_MANAGER__LAST_SYNC:
			return getLastSync();
		case FYPTestPackage.DATA_MANAGER__STATUS:
			return getStatus();
		case FYPTestPackage.DATA_MANAGER__MONITOR_SENSOR:
			return getMonitorSensor();
		case FYPTestPackage.DATA_MANAGER__PASS_DATA:
			if (resolve)
				return getPassData();
			return basicGetPassData();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FYPTestPackage.DATA_MANAGER__DATA_SOURCE:
			setDataSource((String) newValue);
			return;
		case FYPTestPackage.DATA_MANAGER__UPDATE_INTERVAL:
			setUpdateInterval((Integer) newValue);
			return;
		case FYPTestPackage.DATA_MANAGER__LAST_SYNC:
			setLastSync((Date) newValue);
			return;
		case FYPTestPackage.DATA_MANAGER__STATUS:
			setStatus((String) newValue);
			return;
		case FYPTestPackage.DATA_MANAGER__MONITOR_SENSOR:
			getMonitorSensor().clear();
			getMonitorSensor().addAll((Collection<? extends Sensor>) newValue);
			return;
		case FYPTestPackage.DATA_MANAGER__PASS_DATA:
			setPassData((DigitalTwin) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FYPTestPackage.DATA_MANAGER__DATA_SOURCE:
			setDataSource(DATA_SOURCE_EDEFAULT);
			return;
		case FYPTestPackage.DATA_MANAGER__UPDATE_INTERVAL:
			setUpdateInterval(UPDATE_INTERVAL_EDEFAULT);
			return;
		case FYPTestPackage.DATA_MANAGER__LAST_SYNC:
			setLastSync(LAST_SYNC_EDEFAULT);
			return;
		case FYPTestPackage.DATA_MANAGER__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		case FYPTestPackage.DATA_MANAGER__MONITOR_SENSOR:
			getMonitorSensor().clear();
			return;
		case FYPTestPackage.DATA_MANAGER__PASS_DATA:
			setPassData((DigitalTwin) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FYPTestPackage.DATA_MANAGER__DATA_SOURCE:
			return DATA_SOURCE_EDEFAULT == null ? dataSource != null : !DATA_SOURCE_EDEFAULT.equals(dataSource);
		case FYPTestPackage.DATA_MANAGER__UPDATE_INTERVAL:
			return updateInterval != UPDATE_INTERVAL_EDEFAULT;
		case FYPTestPackage.DATA_MANAGER__LAST_SYNC:
			return LAST_SYNC_EDEFAULT == null ? lastSync != null : !LAST_SYNC_EDEFAULT.equals(lastSync);
		case FYPTestPackage.DATA_MANAGER__STATUS:
			return STATUS_EDEFAULT == null ? status != null : !STATUS_EDEFAULT.equals(status);
		case FYPTestPackage.DATA_MANAGER__MONITOR_SENSOR:
			return monitorSensor != null && !monitorSensor.isEmpty();
		case FYPTestPackage.DATA_MANAGER__PASS_DATA:
			return passData != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (dataSource: ");
		result.append(dataSource);
		result.append(", updateInterval: ");
		result.append(updateInterval);
		result.append(", lastSync: ");
		result.append(lastSync);
		result.append(", status: ");
		result.append(status);
		result.append(')');
		return result.toString();
	}

} //DataManagerImpl
