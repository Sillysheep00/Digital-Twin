/**
 */
package fYPTest;

import java.util.Date;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.Sensor#getSensorID <em>Sensor ID</em>}</li>
 *   <li>{@link fYPTest.Sensor#getSensorType <em>Sensor Type</em>}</li>
 *   <li>{@link fYPTest.Sensor#getTimeStamp <em>Time Stamp</em>}</li>
 *   <li>{@link fYPTest.Sensor#getRoomID <em>Room ID</em>}</li>
 *   <li>{@link fYPTest.Sensor#getRoom <em>Room</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getSensor()
 * @model
 * @generated
 */
public interface Sensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Sensor ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor ID</em>' attribute.
	 * @see #setSensorID(String)
	 * @see fYPTest.FYPTestPackage#getSensor_SensorID()
	 * @model
	 * @generated
	 */
	String getSensorID();

	/**
	 * Sets the value of the '{@link fYPTest.Sensor#getSensorID <em>Sensor ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensor ID</em>' attribute.
	 * @see #getSensorID()
	 * @generated
	 */
	void setSensorID(String value);

	/**
	 * Returns the value of the '<em><b>Sensor Type</b></em>' attribute.
	 * The literals are from the enumeration {@link fYPTest.SensorType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor Type</em>' attribute.
	 * @see fYPTest.SensorType
	 * @see #setSensorType(SensorType)
	 * @see fYPTest.FYPTestPackage#getSensor_SensorType()
	 * @model
	 * @generated
	 */
	SensorType getSensorType();

	/**
	 * Sets the value of the '{@link fYPTest.Sensor#getSensorType <em>Sensor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensor Type</em>' attribute.
	 * @see fYPTest.SensorType
	 * @see #getSensorType()
	 * @generated
	 */
	void setSensorType(SensorType value);

	/**
	 * Returns the value of the '<em><b>Time Stamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time Stamp</em>' attribute.
	 * @see #setTimeStamp(Date)
	 * @see fYPTest.FYPTestPackage#getSensor_TimeStamp()
	 * @model
	 * @generated
	 */
	Date getTimeStamp();

	/**
	 * Sets the value of the '{@link fYPTest.Sensor#getTimeStamp <em>Time Stamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time Stamp</em>' attribute.
	 * @see #getTimeStamp()
	 * @generated
	 */
	void setTimeStamp(Date value);

	/**
	 * Returns the value of the '<em><b>Room ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room ID</em>' attribute.
	 * @see #setRoomID(String)
	 * @see fYPTest.FYPTestPackage#getSensor_RoomID()
	 * @model
	 * @generated
	 */
	String getRoomID();

	/**
	 * Sets the value of the '{@link fYPTest.Sensor#getRoomID <em>Room ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Room ID</em>' attribute.
	 * @see #getRoomID()
	 * @generated
	 */
	void setRoomID(String value);

	/**
	 * Returns the value of the '<em><b>Room</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fYPTest.Room#getSensors <em>Sensors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room</em>' container reference.
	 * @see #setRoom(Room)
	 * @see fYPTest.FYPTestPackage#getSensor_Room()
	 * @see fYPTest.Room#getSensors
	 * @model opposite="sensors" required="true" transient="false"
	 * @generated
	 */
	Room getRoom();

	/**
	 * Sets the value of the '{@link fYPTest.Sensor#getRoom <em>Room</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Room</em>' container reference.
	 * @see #getRoom()
	 * @generated
	 */
	void setRoom(Room value);

} // Sensor
