/**
 */
package fYPTest;

import java.util.Date;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Digital Twin</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.DigitalTwin#getTwinID <em>Twin ID</em>}</li>
 *   <li>{@link fYPTest.DigitalTwin#isStatus <em>Status</em>}</li>
 *   <li>{@link fYPTest.DigitalTwin#getLastUpdateTime <em>Last Update Time</em>}</li>
 *   <li>{@link fYPTest.DigitalTwin#getPredictiveModel <em>Predictive Model</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getDigitalTwin()
 * @model
 * @generated
 */
public interface DigitalTwin extends EObject {
	/**
	 * Returns the value of the '<em><b>Twin ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Twin ID</em>' attribute.
	 * @see #setTwinID(String)
	 * @see fYPTest.FYPTestPackage#getDigitalTwin_TwinID()
	 * @model
	 * @generated
	 */
	String getTwinID();

	/**
	 * Sets the value of the '{@link fYPTest.DigitalTwin#getTwinID <em>Twin ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Twin ID</em>' attribute.
	 * @see #getTwinID()
	 * @generated
	 */
	void setTwinID(String value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see fYPTest.FYPTestPackage#getDigitalTwin_Status()
	 * @model
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link fYPTest.DigitalTwin#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Last Update Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Update Time</em>' attribute.
	 * @see #setLastUpdateTime(Date)
	 * @see fYPTest.FYPTestPackage#getDigitalTwin_LastUpdateTime()
	 * @model
	 * @generated
	 */
	Date getLastUpdateTime();

	/**
	 * Sets the value of the '{@link fYPTest.DigitalTwin#getLastUpdateTime <em>Last Update Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Update Time</em>' attribute.
	 * @see #getLastUpdateTime()
	 * @generated
	 */
	void setLastUpdateTime(Date value);

	/**
	 * Returns the value of the '<em><b>Predictive Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Predictive Model</em>' containment reference.
	 * @see #setPredictiveModel(PredictiveModel)
	 * @see fYPTest.FYPTestPackage#getDigitalTwin_PredictiveModel()
	 * @model containment="true" required="true"
	 * @generated
	 */
	PredictiveModel getPredictiveModel();

	/**
	 * Sets the value of the '{@link fYPTest.DigitalTwin#getPredictiveModel <em>Predictive Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Predictive Model</em>' containment reference.
	 * @see #getPredictiveModel()
	 * @generated
	 */
	void setPredictiveModel(PredictiveModel value);

} // DigitalTwin
