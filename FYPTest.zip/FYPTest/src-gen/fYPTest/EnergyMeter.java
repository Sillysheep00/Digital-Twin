/**
 */
package fYPTest;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Energy Meter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.EnergyMeter#getEnergyConsumed <em>Energy Consumed</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getEnergyMeter()
 * @model
 * @generated
 */
public interface EnergyMeter extends Sensor {
	/**
	 * Returns the value of the '<em><b>Energy Consumed</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Energy Consumed</em>' attribute.
	 * @see #setEnergyConsumed(double)
	 * @see fYPTest.FYPTestPackage#getEnergyMeter_EnergyConsumed()
	 * @model default="0.0"
	 * @generated
	 */
	double getEnergyConsumed();

	/**
	 * Sets the value of the '{@link fYPTest.EnergyMeter#getEnergyConsumed <em>Energy Consumed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Energy Consumed</em>' attribute.
	 * @see #getEnergyConsumed()
	 * @generated
	 */
	void setEnergyConsumed(double value);

} // EnergyMeter
