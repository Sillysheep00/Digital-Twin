/**
 */
package fYPTest;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.Room#getRoomID <em>Room ID</em>}</li>
 *   <li>{@link fYPTest.Room#getRoomName <em>Room Name</em>}</li>
 *   <li>{@link fYPTest.Room#getArea <em>Area</em>}</li>
 *   <li>{@link fYPTest.Room#getCurrentTemp <em>Current Temp</em>}</li>
 *   <li>{@link fYPTest.Room#getEnergyUsage <em>Energy Usage</em>}</li>
 *   <li>{@link fYPTest.Room#getSensors <em>Sensors</em>}</li>
 *   <li>{@link fYPTest.Room#getHvac <em>Hvac</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getRoom()
 * @model
 * @generated
 */
public interface Room extends EObject {
	/**
	 * Returns the value of the '<em><b>Room ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room ID</em>' attribute.
	 * @see #setRoomID(String)
	 * @see fYPTest.FYPTestPackage#getRoom_RoomID()
	 * @model
	 * @generated
	 */
	String getRoomID();

	/**
	 * Sets the value of the '{@link fYPTest.Room#getRoomID <em>Room ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Room ID</em>' attribute.
	 * @see #getRoomID()
	 * @generated
	 */
	void setRoomID(String value);

	/**
	 * Returns the value of the '<em><b>Room Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room Name</em>' attribute.
	 * @see #setRoomName(String)
	 * @see fYPTest.FYPTestPackage#getRoom_RoomName()
	 * @model
	 * @generated
	 */
	String getRoomName();

	/**
	 * Sets the value of the '{@link fYPTest.Room#getRoomName <em>Room Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Room Name</em>' attribute.
	 * @see #getRoomName()
	 * @generated
	 */
	void setRoomName(String value);

	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(double)
	 * @see fYPTest.FYPTestPackage#getRoom_Area()
	 * @model
	 * @generated
	 */
	double getArea();

	/**
	 * Sets the value of the '{@link fYPTest.Room#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(double value);

	/**
	 * Returns the value of the '<em><b>Current Temp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Temp</em>' attribute.
	 * @see #setCurrentTemp(double)
	 * @see fYPTest.FYPTestPackage#getRoom_CurrentTemp()
	 * @model
	 * @generated
	 */
	double getCurrentTemp();

	/**
	 * Sets the value of the '{@link fYPTest.Room#getCurrentTemp <em>Current Temp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Temp</em>' attribute.
	 * @see #getCurrentTemp()
	 * @generated
	 */
	void setCurrentTemp(double value);

	/**
	 * Returns the value of the '<em><b>Energy Usage</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Energy Usage</em>' attribute.
	 * @see #setEnergyUsage(float)
	 * @see fYPTest.FYPTestPackage#getRoom_EnergyUsage()
	 * @model default="0.0"
	 * @generated
	 */
	float getEnergyUsage();

	/**
	 * Sets the value of the '{@link fYPTest.Room#getEnergyUsage <em>Energy Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Energy Usage</em>' attribute.
	 * @see #getEnergyUsage()
	 * @generated
	 */
	void setEnergyUsage(float value);

	/**
	 * Returns the value of the '<em><b>Sensors</b></em>' containment reference list.
	 * The list contents are of type {@link fYPTest.Sensor}.
	 * It is bidirectional and its opposite is '{@link fYPTest.Sensor#getRoom <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensors</em>' containment reference list.
	 * @see fYPTest.FYPTestPackage#getRoom_Sensors()
	 * @see fYPTest.Sensor#getRoom
	 * @model opposite="room" containment="true"
	 * @generated
	 */
	EList<Sensor> getSensors();

	/**
	 * Returns the value of the '<em><b>Hvac</b></em>' containment reference.
	 * It is bidirectional and its opposite is '{@link fYPTest.HVACSystem#getRoom <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hvac</em>' containment reference.
	 * @see #setHvac(HVACSystem)
	 * @see fYPTest.FYPTestPackage#getRoom_Hvac()
	 * @see fYPTest.HVACSystem#getRoom
	 * @model opposite="room" containment="true"
	 * @generated
	 */
	HVACSystem getHvac();

	/**
	 * Sets the value of the '{@link fYPTest.Room#getHvac <em>Hvac</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hvac</em>' containment reference.
	 * @see #getHvac()
	 * @generated
	 */
	void setHvac(HVACSystem value);

} // Room
