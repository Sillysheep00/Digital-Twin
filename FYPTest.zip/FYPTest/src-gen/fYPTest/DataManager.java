/**
 */
package fYPTest;

import java.util.Date;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.DataManager#getDataSource <em>Data Source</em>}</li>
 *   <li>{@link fYPTest.DataManager#getUpdateInterval <em>Update Interval</em>}</li>
 *   <li>{@link fYPTest.DataManager#getLastSync <em>Last Sync</em>}</li>
 *   <li>{@link fYPTest.DataManager#getStatus <em>Status</em>}</li>
 *   <li>{@link fYPTest.DataManager#getMonitorSensor <em>Monitor Sensor</em>}</li>
 *   <li>{@link fYPTest.DataManager#getPassData <em>Pass Data</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getDataManager()
 * @model
 * @generated
 */
public interface DataManager extends EObject {
	/**
	 * Returns the value of the '<em><b>Data Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Source</em>' attribute.
	 * @see #setDataSource(String)
	 * @see fYPTest.FYPTestPackage#getDataManager_DataSource()
	 * @model
	 * @generated
	 */
	String getDataSource();

	/**
	 * Sets the value of the '{@link fYPTest.DataManager#getDataSource <em>Data Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Source</em>' attribute.
	 * @see #getDataSource()
	 * @generated
	 */
	void setDataSource(String value);

	/**
	 * Returns the value of the '<em><b>Update Interval</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Update Interval</em>' attribute.
	 * @see #setUpdateInterval(int)
	 * @see fYPTest.FYPTestPackage#getDataManager_UpdateInterval()
	 * @model
	 * @generated
	 */
	int getUpdateInterval();

	/**
	 * Sets the value of the '{@link fYPTest.DataManager#getUpdateInterval <em>Update Interval</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Update Interval</em>' attribute.
	 * @see #getUpdateInterval()
	 * @generated
	 */
	void setUpdateInterval(int value);

	/**
	 * Returns the value of the '<em><b>Last Sync</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Sync</em>' attribute.
	 * @see #setLastSync(Date)
	 * @see fYPTest.FYPTestPackage#getDataManager_LastSync()
	 * @model
	 * @generated
	 */
	Date getLastSync();

	/**
	 * Sets the value of the '{@link fYPTest.DataManager#getLastSync <em>Last Sync</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Sync</em>' attribute.
	 * @see #getLastSync()
	 * @generated
	 */
	void setLastSync(Date value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(String)
	 * @see fYPTest.FYPTestPackage#getDataManager_Status()
	 * @model
	 * @generated
	 */
	String getStatus();

	/**
	 * Sets the value of the '{@link fYPTest.DataManager#getStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #getStatus()
	 * @generated
	 */
	void setStatus(String value);

	/**
	 * Returns the value of the '<em><b>Monitor Sensor</b></em>' reference list.
	 * The list contents are of type {@link fYPTest.Sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitor Sensor</em>' reference list.
	 * @see fYPTest.FYPTestPackage#getDataManager_MonitorSensor()
	 * @model
	 * @generated
	 */
	EList<Sensor> getMonitorSensor();

	/**
	 * Returns the value of the '<em><b>Pass Data</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pass Data</em>' reference.
	 * @see #setPassData(DigitalTwin)
	 * @see fYPTest.FYPTestPackage#getDataManager_PassData()
	 * @model required="true"
	 * @generated
	 */
	DigitalTwin getPassData();

	/**
	 * Sets the value of the '{@link fYPTest.DataManager#getPassData <em>Pass Data</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pass Data</em>' reference.
	 * @see #getPassData()
	 * @generated
	 */
	void setPassData(DigitalTwin value);

} // DataManager
