/**
 */
package fYPTest;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Floor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.Floor#getFloorID <em>Floor ID</em>}</li>
 *   <li>{@link fYPTest.Floor#getArea <em>Area</em>}</li>
 *   <li>{@link fYPTest.Floor#getRoom <em>Room</em>}</li>
 *   <li>{@link fYPTest.Floor#getBuilding <em>Building</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getFloor()
 * @model
 * @generated
 */
public interface Floor extends EObject {
	/**
	 * Returns the value of the '<em><b>Floor ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor ID</em>' attribute.
	 * @see #setFloorID(String)
	 * @see fYPTest.FYPTestPackage#getFloor_FloorID()
	 * @model
	 * @generated
	 */
	String getFloorID();

	/**
	 * Sets the value of the '{@link fYPTest.Floor#getFloorID <em>Floor ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Floor ID</em>' attribute.
	 * @see #getFloorID()
	 * @generated
	 */
	void setFloorID(String value);

	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(double)
	 * @see fYPTest.FYPTestPackage#getFloor_Area()
	 * @model
	 * @generated
	 */
	double getArea();

	/**
	 * Sets the value of the '{@link fYPTest.Floor#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(double value);

	/**
	 * Returns the value of the '<em><b>Room</b></em>' containment reference list.
	 * The list contents are of type {@link fYPTest.Room}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room</em>' containment reference list.
	 * @see fYPTest.FYPTestPackage#getFloor_Room()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Room> getRoom();

	/**
	 * Returns the value of the '<em><b>Building</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fYPTest.Building#getFloor <em>Floor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Building</em>' container reference.
	 * @see #setBuilding(Building)
	 * @see fYPTest.FYPTestPackage#getFloor_Building()
	 * @see fYPTest.Building#getFloor
	 * @model opposite="floor" required="true" transient="false"
	 * @generated
	 */
	Building getBuilding();

	/**
	 * Sets the value of the '{@link fYPTest.Floor#getBuilding <em>Building</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Building</em>' container reference.
	 * @see #getBuilding()
	 * @generated
	 */
	void setBuilding(Building value);

} // Floor
