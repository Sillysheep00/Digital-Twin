/**
 */
package fYPTest;

import java.util.Date;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Predictive Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.PredictiveModel#getModelID <em>Model ID</em>}</li>
 *   <li>{@link fYPTest.PredictiveModel#getModelType <em>Model Type</em>}</li>
 *   <li>{@link fYPTest.PredictiveModel#getInputVar <em>Input Var</em>}</li>
 *   <li>{@link fYPTest.PredictiveModel#getOutputVar <em>Output Var</em>}</li>
 *   <li>{@link fYPTest.PredictiveModel#getAccuracy <em>Accuracy</em>}</li>
 *   <li>{@link fYPTest.PredictiveModel#getLastTrained <em>Last Trained</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getPredictiveModel()
 * @model
 * @generated
 */
public interface PredictiveModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Model ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model ID</em>' attribute.
	 * @see #setModelID(String)
	 * @see fYPTest.FYPTestPackage#getPredictiveModel_ModelID()
	 * @model
	 * @generated
	 */
	String getModelID();

	/**
	 * Sets the value of the '{@link fYPTest.PredictiveModel#getModelID <em>Model ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model ID</em>' attribute.
	 * @see #getModelID()
	 * @generated
	 */
	void setModelID(String value);

	/**
	 * Returns the value of the '<em><b>Model Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model Type</em>' attribute.
	 * @see #setModelType(String)
	 * @see fYPTest.FYPTestPackage#getPredictiveModel_ModelType()
	 * @model
	 * @generated
	 */
	String getModelType();

	/**
	 * Sets the value of the '{@link fYPTest.PredictiveModel#getModelType <em>Model Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model Type</em>' attribute.
	 * @see #getModelType()
	 * @generated
	 */
	void setModelType(String value);

	/**
	 * Returns the value of the '<em><b>Input Var</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Var</em>' attribute.
	 * @see #setInputVar(String)
	 * @see fYPTest.FYPTestPackage#getPredictiveModel_InputVar()
	 * @model
	 * @generated
	 */
	String getInputVar();

	/**
	 * Sets the value of the '{@link fYPTest.PredictiveModel#getInputVar <em>Input Var</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input Var</em>' attribute.
	 * @see #getInputVar()
	 * @generated
	 */
	void setInputVar(String value);

	/**
	 * Returns the value of the '<em><b>Output Var</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Output Var</em>' attribute.
	 * @see #setOutputVar(String)
	 * @see fYPTest.FYPTestPackage#getPredictiveModel_OutputVar()
	 * @model
	 * @generated
	 */
	String getOutputVar();

	/**
	 * Sets the value of the '{@link fYPTest.PredictiveModel#getOutputVar <em>Output Var</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output Var</em>' attribute.
	 * @see #getOutputVar()
	 * @generated
	 */
	void setOutputVar(String value);

	/**
	 * Returns the value of the '<em><b>Accuracy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Accuracy</em>' attribute.
	 * @see #setAccuracy(double)
	 * @see fYPTest.FYPTestPackage#getPredictiveModel_Accuracy()
	 * @model
	 * @generated
	 */
	double getAccuracy();

	/**
	 * Sets the value of the '{@link fYPTest.PredictiveModel#getAccuracy <em>Accuracy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accuracy</em>' attribute.
	 * @see #getAccuracy()
	 * @generated
	 */
	void setAccuracy(double value);

	/**
	 * Returns the value of the '<em><b>Last Trained</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Trained</em>' attribute.
	 * @see #setLastTrained(Date)
	 * @see fYPTest.FYPTestPackage#getPredictiveModel_LastTrained()
	 * @model
	 * @generated
	 */
	Date getLastTrained();

	/**
	 * Sets the value of the '{@link fYPTest.PredictiveModel#getLastTrained <em>Last Trained</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Trained</em>' attribute.
	 * @see #getLastTrained()
	 * @generated
	 */
	void setLastTrained(Date value);

} // PredictiveModel
