/**
 */
package fYPTest;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>HVAC System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.HVACSystem#getHvacID <em>Hvac ID</em>}</li>
 *   <li>{@link fYPTest.HVACSystem#getPowerUsage <em>Power Usage</em>}</li>
 *   <li>{@link fYPTest.HVACSystem#isStatus <em>Status</em>}</li>
 *   <li>{@link fYPTest.HVACSystem#getLinkedRoom <em>Linked Room</em>}</li>
 *   <li>{@link fYPTest.HVACSystem#getRoom <em>Room</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getHVACSystem()
 * @model
 * @generated
 */
public interface HVACSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Hvac ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hvac ID</em>' attribute.
	 * @see #setHvacID(String)
	 * @see fYPTest.FYPTestPackage#getHVACSystem_HvacID()
	 * @model
	 * @generated
	 */
	String getHvacID();

	/**
	 * Sets the value of the '{@link fYPTest.HVACSystem#getHvacID <em>Hvac ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hvac ID</em>' attribute.
	 * @see #getHvacID()
	 * @generated
	 */
	void setHvacID(String value);

	/**
	 * Returns the value of the '<em><b>Power Usage</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power Usage</em>' attribute.
	 * @see #setPowerUsage(float)
	 * @see fYPTest.FYPTestPackage#getHVACSystem_PowerUsage()
	 * @model default="0.0"
	 * @generated
	 */
	float getPowerUsage();

	/**
	 * Sets the value of the '{@link fYPTest.HVACSystem#getPowerUsage <em>Power Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Power Usage</em>' attribute.
	 * @see #getPowerUsage()
	 * @generated
	 */
	void setPowerUsage(float value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see fYPTest.FYPTestPackage#getHVACSystem_Status()
	 * @model
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link fYPTest.HVACSystem#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Linked Room</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Linked Room</em>' attribute.
	 * @see #setLinkedRoom(String)
	 * @see fYPTest.FYPTestPackage#getHVACSystem_LinkedRoom()
	 * @model
	 * @generated
	 */
	String getLinkedRoom();

	/**
	 * Sets the value of the '{@link fYPTest.HVACSystem#getLinkedRoom <em>Linked Room</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Linked Room</em>' attribute.
	 * @see #getLinkedRoom()
	 * @generated
	 */
	void setLinkedRoom(String value);

	/**
	 * Returns the value of the '<em><b>Room</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fYPTest.Room#getHvac <em>Hvac</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room</em>' container reference.
	 * @see #setRoom(Room)
	 * @see fYPTest.FYPTestPackage#getHVACSystem_Room()
	 * @see fYPTest.Room#getHvac
	 * @model opposite="hvac" required="true" transient="false"
	 * @generated
	 */
	Room getRoom();

	/**
	 * Sets the value of the '{@link fYPTest.HVACSystem#getRoom <em>Room</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Room</em>' container reference.
	 * @see #getRoom()
	 * @generated
	 */
	void setRoom(Room value);

} // HVACSystem
