/**
 */
package fYPTest;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Building</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.Building#getBuildingID <em>Building ID</em>}</li>
 *   <li>{@link fYPTest.Building#getName <em>Name</em>}</li>
 *   <li>{@link fYPTest.Building#getModel3DPath <em>Model3 DPath</em>}</li>
 *   <li>{@link fYPTest.Building#getFloor <em>Floor</em>}</li>
 *   <li>{@link fYPTest.Building#getDigitalTwins <em>Digital Twins</em>}</li>
 *   <li>{@link fYPTest.Building#getOwns <em>Owns</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getBuilding()
 * @model
 * @generated
 */
public interface Building extends EObject {
	/**
	 * Returns the value of the '<em><b>Building ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Building ID</em>' attribute.
	 * @see #setBuildingID(String)
	 * @see fYPTest.FYPTestPackage#getBuilding_BuildingID()
	 * @model
	 * @generated
	 */
	String getBuildingID();

	/**
	 * Sets the value of the '{@link fYPTest.Building#getBuildingID <em>Building ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Building ID</em>' attribute.
	 * @see #getBuildingID()
	 * @generated
	 */
	void setBuildingID(String value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see fYPTest.FYPTestPackage#getBuilding_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link fYPTest.Building#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Model3 DPath</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model3 DPath</em>' attribute.
	 * @see #setModel3DPath(String)
	 * @see fYPTest.FYPTestPackage#getBuilding_Model3DPath()
	 * @model
	 * @generated
	 */
	String getModel3DPath();

	/**
	 * Sets the value of the '{@link fYPTest.Building#getModel3DPath <em>Model3 DPath</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model3 DPath</em>' attribute.
	 * @see #getModel3DPath()
	 * @generated
	 */
	void setModel3DPath(String value);

	/**
	 * Returns the value of the '<em><b>Floor</b></em>' containment reference list.
	 * The list contents are of type {@link fYPTest.Floor}.
	 * It is bidirectional and its opposite is '{@link fYPTest.Floor#getBuilding <em>Building</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Floor</em>' containment reference list.
	 * @see fYPTest.FYPTestPackage#getBuilding_Floor()
	 * @see fYPTest.Floor#getBuilding
	 * @model opposite="building" containment="true" required="true"
	 * @generated
	 */
	EList<Floor> getFloor();

	/**
	 * Returns the value of the '<em><b>Digital Twins</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Digital Twins</em>' containment reference.
	 * @see #setDigitalTwins(DigitalTwin)
	 * @see fYPTest.FYPTestPackage#getBuilding_DigitalTwins()
	 * @model containment="true" required="true"
	 * @generated
	 */
	DigitalTwin getDigitalTwins();

	/**
	 * Sets the value of the '{@link fYPTest.Building#getDigitalTwins <em>Digital Twins</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Digital Twins</em>' containment reference.
	 * @see #getDigitalTwins()
	 * @generated
	 */
	void setDigitalTwins(DigitalTwin value);

	/**
	 * Returns the value of the '<em><b>Owns</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owns</em>' containment reference.
	 * @see #setOwns(DataManager)
	 * @see fYPTest.FYPTestPackage#getBuilding_Owns()
	 * @model containment="true" required="true"
	 * @generated
	 */
	DataManager getOwns();

	/**
	 * Sets the value of the '{@link fYPTest.Building#getOwns <em>Owns</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owns</em>' containment reference.
	 * @see #getOwns()
	 * @generated
	 */
	void setOwns(DataManager value);

} // Building
