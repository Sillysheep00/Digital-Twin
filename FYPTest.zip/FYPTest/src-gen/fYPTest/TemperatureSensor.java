/**
 */
package fYPTest;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Temperature Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fYPTest.TemperatureSensor#getTemperature <em>Temperature</em>}</li>
 * </ul>
 *
 * @see fYPTest.FYPTestPackage#getTemperatureSensor()
 * @model
 * @generated
 */
public interface TemperatureSensor extends Sensor {
	/**
	 * Returns the value of the '<em><b>Temperature</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperature</em>' attribute.
	 * @see #setTemperature(double)
	 * @see fYPTest.FYPTestPackage#getTemperatureSensor_Temperature()
	 * @model default="0.0"
	 * @generated
	 */
	double getTemperature();

	/**
	 * Sets the value of the '{@link fYPTest.TemperatureSensor#getTemperature <em>Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperature</em>' attribute.
	 * @see #getTemperature()
	 * @generated
	 */
	void setTemperature(double value);

} // TemperatureSensor
